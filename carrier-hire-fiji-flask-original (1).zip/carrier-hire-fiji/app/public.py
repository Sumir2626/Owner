import json
import math
import re
import secrets
import time
from datetime import datetime, timedelta, timezone

from flask import (Blueprint, abort, current_app, flash, jsonify, redirect, render_template,
                   request, send_from_directory, session, url_for, Response)
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

from . import mailer, maps, pricing
from .db import audit, current_pricing, get_db, get_settings
from .security import ip_hash, rate_limited
from .util import (clean, new_reference, now_fiji, parse_date, parse_int, parse_time,
                   utc_now_iso, valid_email, valid_phone)

bp = Blueprint("public", __name__)

QUOTE_TOKEN_MAX_AGE = 24 * 3600
PASSENGER_VEHICLE_OPTIONS = ["No preference", "Car / sedan", "SUV", "Van / minivan", "Minibus", "Coach / bus"]
TERMINAL = ("Completed", "Cancelled", "Rejected")


def ser(salt):
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"], salt=salt)


# =============================================================== static pages
def _faq_items(text):
    items = []
    for block in re.split(r"\n\s*\n", (text or "").strip()):
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        if len(lines) >= 2:
            items.append((lines[0], " ".join(lines[1:])))
    return items


def _testimonials(text):
    out = []
    for line in (text or "").splitlines():
        if "|" in line:
            n, q = line.split("|", 1)
            if n.strip() and q.strip():
                out.append((n.strip(), q.strip()))
    return out


@bp.get("/")
def home():
    cfg = current_pricing()
    example = pricing.build_quote([100000], "one_way", cfg)
    vehicles = get_db().execute(
        "SELECT * FROM vehicles WHERE active=1 AND show_public=1 ORDER BY vehicle_type LIMIT 3").fetchall()
    return render_template("home.html", example=example, vehicles=vehicles,
                           testimonials=_testimonials(get_settings()["testimonials_text"]))


@bp.get("/about")
def about():
    return render_template("about.html")


@bp.get("/services")
def services():
    return render_template("services.html")


@bp.get("/vehicles")
def vehicles():
    rows = get_db().execute(
        "SELECT * FROM vehicles WHERE active=1 AND show_public=1 ORDER BY vehicle_type, name").fetchall()
    return render_template("vehicles.html", vehicles=rows)


@bp.get("/faq")
def faq():
    cfg = current_pricing()
    return render_template("faq.html", items=_faq_items(get_settings()["faq_text"]), cfg=cfg)


@bp.get("/terms")
def terms():
    return render_template("legal.html", page="terms", title="Terms and Conditions",
                           body=get_settings()["terms_text"])


@bp.get("/privacy")
def privacy():
    return render_template("legal.html", page="privacy", title="Privacy Policy",
                           body=get_settings()["privacy_text"])


@bp.get("/cancellation-refunds")
def cancellation():
    return render_template("legal.html", page="cancellation", title="Cancellation and Refund Policy",
                           body=get_settings()["cancellation_text"])


@bp.route("/contact", methods=["GET", "POST"])
def contact():
    form = {}
    if request.method == "POST":
        form = {k: clean(request.form.get(k), 2000 if k == "message" else 120)
                for k in ("name", "email", "phone", "message")}
        errors = []
        if request.form.get("website"):  # honeypot
            return redirect(url_for("public.contact"))
        if rate_limited("enquiry", 5, 3600):
            errors.append("Too many messages from your connection. Please try again later.")
        if len(form["name"]) < 2:
            errors.append("Please enter your name.")
        if not valid_email(form["email"]):
            errors.append("Please enter a valid email address.")
        if form["phone"] and not valid_phone(form["phone"]):
            errors.append("Please enter a valid phone number or leave it blank.")
        if len(form["message"]) < 5:
            errors.append("Please enter your message.")
        if not errors:
            db = get_db()
            db.execute("INSERT INTO enquiries(name,email,phone,message,created_at) VALUES(?,?,?,?,?)",
                       (form["name"], form["email"], form["phone"], form["message"], utc_now_iso()))
            db.commit()
            mailer.admin_enquiry(form["name"], form["email"], form["phone"], form["message"])
            flash("Thank you - your message has been sent. We will reply as soon as we can.", "ok")
            return redirect(url_for("public.contact"))
        for e in errors:
            flash(e, "error")
    return render_template("contact.html", form=form)


@bp.get("/robots.txt")
def robots():
    base = current_app.config["SITE_URL"]
    return Response(f"User-agent: *\nDisallow: /admin\nDisallow: /api/\nDisallow: /book\n"
                    f"Disallow: /booking-status\nSitemap: {base}/sitemap.xml\n", mimetype="text/plain")


@bp.get("/sitemap.xml")
def sitemap():
    base = current_app.config["SITE_URL"]
    paths = ["/", "/about", "/services", "/vehicles", "/quote", "/faq", "/contact",
             "/terms", "/privacy", "/cancellation-refunds"]
    xml = "".join(f"<url><loc>{base}{p}</loc></url>" for p in paths)
    return Response(f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns='
                    f'"http://www.sitemaps.org/schemas/sitemap/0.9">{xml}</urlset>', mimetype="application/xml")


@bp.get("/media/public/<path:name>")
def public_media(name):
    return send_from_directory(f"{current_app.config['UPLOAD_DIR']}/public", name)


# =============================================================== quotation
@bp.get("/quote")
def quote_page():
    s = get_settings()
    return render_template(
        "quote.html", maps_page=True,
        maps_key=current_app.config["GOOGLE_MAPS_BROWSER_KEY"],
        map_id=current_app.config["GOOGLE_MAP_ID"],
        manual_enabled=s["manual_quote_enabled"] == "1",
        preset_type=request.args.get("type") if request.args.get("type") in ("passenger", "goods") else "",
    )


def parse_point(p):
    if not isinstance(p, dict):
        return None
    try:
        lat, lng = float(p.get("lat")), float(p.get("lng"))
    except (TypeError, ValueError):
        return None
    if not (math.isfinite(lat) and math.isfinite(lng)) or abs(lat) > 90 or abs(lng) > 180:
        return None
    return {"address": clean(p.get("address"), 200) or f"{lat:.5f}, {lng:.5f}",
            "lat": round(lat, 6), "lng": round(lng, 6), "place_id": clean(p.get("place_id"), 200)}


def _fail(code, message, http=200):
    s = get_settings()
    manual = code in ("no_route", "api_error", "not_configured") and s["manual_quote_enabled"] == "1"
    return jsonify(ok=False, code=code, message=message, manual_allowed=manual), http


@bp.post("/api/quote")
def api_quote():
    """Calculate distance (Google Routes) and price (our formula). Stateless and server-side only."""
    if rate_limited("quote", 40, 600):
        return _fail("rate_limited", "Too many quotation requests. Please wait a few minutes and try again.", 429)
    data = request.get_json(silent=True) or {}
    jt = data.get("journey_type")
    if jt not in ("one_way", "return"):
        return _fail("invalid", "Please choose one-way or return.", 400)
    legs = []
    o, d = parse_point(data.get("origin")), parse_point(data.get("destination"))
    if not o or not d:
        return _fail("invalid", "Please choose both a pickup location and a destination.", 400)
    legs.append((o, d))
    diff = jt == "return" and bool(data.get("return_different"))
    if diff:
        ro, rd = parse_point(data.get("return_origin")), parse_point(data.get("return_destination"))
        if not ro or not rd:
            return _fail("invalid", "Please choose the return pickup and return destination.", 400)
        legs.append((ro, rd))

    for a, b in legs:
        for pt in (a, b):
            if not maps.in_fiji(pt["lat"], pt["lng"]):
                return _fail("outside_fiji", "Both locations must be within Fiji. Please choose a Fiji location.", 422)
        if maps.haversine_km(a, b) < 0.03:
            return _fail("same_place", "The pickup and destination are the same place. Please choose a different destination.", 422)

    key = current_app.config["GOOGLE_MAPS_SERVER_KEY"]
    if not key:
        return _fail("not_configured", "Online route pricing is not available right now. You can request a manual quotation.")
    routes = []
    for a, b in legs:
        try:
            r = maps.compute_route(a, b, key)
        except maps.RouteUnavailable:
            return _fail("no_route",
                         "We could not find a drivable road route between these locations. If the journey needs a "
                         "ferry crossing, sea transport or a very remote location, please request a manual quotation.")
        except maps.RouteError as exc:
            current_app.logger.warning("Routes API problem: %s", str(exc)[:300])
            return _fail("api_error", "We could not calculate the route just now. No price has been calculated - "
                                      "please try again or request a manual quotation.")
        if r.distance_m < 30:
            return _fail("same_place", "The pickup and destination are effectively the same place.", 422)
        routes.append(r)

    cfg = current_pricing()
    quote = pricing.build_quote([r.distance_m for r in routes], jt, cfg, return_different=diff)
    payload = {"v": 1, "jt": jt, "diff": diff, "cfg": cfg.to_dict(),
               "legs": [{"o": a, "d": b, "m": r.distance_m, "s": r.duration_s} for (a, b), r in zip(legs, routes)]}
    return jsonify(
        ok=True, quote=quote, token=ser("quote").dumps(payload),
        routes=[{"polyline": r.polyline, "distance_m": r.distance_m} for r in routes],
        maps_links=[maps.maps_directions_url(a, b) for a, b in legs],
    )


def verify_quote_token(token):
    """Return (payload, quote) rebuilt from the signed inputs, or (None, None)."""
    try:
        payload = ser("quote").loads(token, max_age=QUOTE_TOKEN_MAX_AGE)
        cfg = pricing.PricingConfig.from_dict(payload["cfg"])
        quote = pricing.build_quote([l["m"] for l in payload["legs"]], payload["jt"], cfg, payload["diff"])
        return payload, quote
    except (BadSignature, SignatureExpired, KeyError, ValueError, TypeError):
        return None, None


# =============================================================== booking flow
def _save_draft(data):
    db = get_db()
    did = secrets.token_urlsafe(18)
    db.execute("DELETE FROM drafts WHERE created_at < ?", ((datetime.now(timezone.utc) - timedelta(days=2)).replace(microsecond=0).isoformat(),))
    db.execute("INSERT INTO drafts(id,payload,created_at) VALUES(?,?,?)",
               (did, json.dumps(data), utc_now_iso()))
    db.commit()
    session["draft_id"] = did


def _load_draft():
    did = session.get("draft_id")
    if not did:
        return None
    row = get_db().execute("SELECT payload FROM drafts WHERE id=?", (did,)).fetchone()
    return json.loads(row["payload"]) if row else None


@bp.post("/book/start")
def book_start():
    """Called by 'Proceed to Booking' / 'Request a Manual Quote'. Keeps data server-side, not in the URL."""
    data = request.get_json(silent=True) or {}
    btype = data.get("booking_type")
    if btype not in ("passenger", "goods"):
        return jsonify(ok=False, message="Please choose passenger or goods transport first."), 400
    if data.get("mode") == "auto":
        payload, quote = verify_quote_token(data.get("token", ""))
        if not payload:
            return jsonify(ok=False, message="Your quotation has expired. Please recalculate it."), 400
        _save_draft({"mode": "auto", "token": data["token"], "booking_type": btype})
    else:
        jt = data.get("journey_type") if data.get("journey_type") in ("one_way", "return") else "one_way"
        pts = {}
        for k in ("origin", "destination"):
            p = data.get(k) or {}
            addr = clean(p.get("address"), 200)
            lat, lng = p.get("lat"), p.get("lng")
            try:
                lat, lng = float(lat), float(lng)
                if not maps.in_fiji(lat, lng):
                    return jsonify(ok=False, message="Both locations must be within Fiji."), 422
            except (TypeError, ValueError):
                lat = lng = None
            pts[k] = {"address": addr, "lat": lat, "lng": lng, "place_id": clean(p.get("place_id"), 200)}
        _save_draft({"mode": "manual", "booking_type": btype, "journey_type": jt, "points": pts,
                     "reason": clean(data.get("reason"), 60)})
    return jsonify(ok=True, redirect=url_for("public.book"))


def _draft_context(draft):
    if draft["mode"] == "auto":
        payload, quote = verify_quote_token(draft["token"])
        if not payload:
            return None
        first = payload["legs"][0]
        ctx = {"payload": payload, "quote": quote, "pickup": first["o"], "dest": first["d"],
               "journey_type": payload["jt"], "diff": payload["diff"]}
        if payload["diff"]:
            ctx["ret_pickup"], ctx["ret_dest"] = payload["legs"][1]["o"], payload["legs"][1]["d"]
        return ctx
    pts = draft["points"]
    return {"payload": None, "quote": None, "pickup": pts["origin"], "dest": pts["destination"],
            "journey_type": draft.get("journey_type", "one_way"), "diff": False}


@bp.get("/book")
def book():
    draft = _load_draft()
    if not draft:
        flash("Please start with a quote so we can capture your pickup and destination.", "info")
        return redirect(url_for("public.quote_page"))
    ctx = _draft_context(draft)
    if not ctx:
        flash("Your quotation has expired. Please calculate it again.", "error")
        return redirect(url_for("public.quote_page"))
    form = {"booking_type": draft["booking_type"], "contact_method": "phone",
            "pickup_address": ctx["pickup"]["address"], "dest_address": ctx["dest"]["address"]}
    return render_template("book.html", ctx=ctx, draft=draft, form=form, errors={},
                           vehicle_options=PASSENGER_VEHICLE_OPTIONS, form_ts=ser("form").dumps(time.time()))


def _sniff_image(head: bytes):
    if head.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    return None


def validate_booking(form, ctx, draft, files):
    e, v = {}, {}
    v["booking_type"] = form.get("booking_type") if form.get("booking_type") in ("passenger", "goods") else ""
    if not v["booking_type"]:
        e["booking_type"] = "Please choose passenger or goods transport."
    v["customer_name"] = clean(form.get("customer_name"), 100)
    if len(v["customer_name"]) < 2:
        e["customer_name"] = "Please enter your full name."
    v["mobile"] = clean(form.get("mobile"), 24)
    if not valid_phone(v["mobile"]):
        e["mobile"] = "Please enter a valid mobile number (digits, +, spaces and dashes only)."
    v["email"] = clean(form.get("email"), 254).lower()
    if not valid_email(v["email"]):
        e["email"] = "Please enter a valid email address."
    v["contact_method"] = form.get("contact_method") if form.get("contact_method") in ("phone", "whatsapp", "email") else ""
    if not v["contact_method"]:
        e["contact_method"] = "Please choose how we should contact you."

    manual = ctx["payload"] is None
    if manual:
        v["pickup_address"] = clean(form.get("pickup_address"), 200)
        v["dest_address"] = clean(form.get("dest_address"), 200)
        if not v["pickup_address"]:
            e["pickup_address"] = "Please enter the pickup location."
        if not v["dest_address"]:
            e["dest_address"] = "Please enter the destination."
        v["journey_type"] = form.get("journey_type") if form.get("journey_type") in ("one_way", "return") else ""
        if not v["journey_type"]:
            e["journey_type"] = "Please choose one-way or return."
    else:
        v["pickup_address"], v["dest_address"] = ctx["pickup"]["address"], ctx["dest"]["address"]
        v["journey_type"] = ctx["journey_type"]

    pd, pt = parse_date(form.get("pickup_date")), parse_time(form.get("pickup_time"))
    v["pickup_date"], v["pickup_time"] = clean(form.get("pickup_date"), 10), clean(form.get("pickup_time"), 5)
    if not pd:
        e["pickup_date"] = "Please choose a pickup date."
    if not pt:
        e["pickup_time"] = "Please choose a pickup time."
    pdt = None
    if pd and pt:
        pdt = datetime.combine(pd, pt)
        if pdt < now_fiji():
            e["pickup_date"] = "The pickup date and time must be in the future (Fiji time)."
    v["pickup_dt"] = pdt.strftime("%Y-%m-%dT%H:%M") if pdt else ""

    v["return_date"] = v["return_time"] = v["return_dt"] = None
    if v["journey_type"] == "return":
        rd, rt = parse_date(form.get("return_date")), parse_time(form.get("return_time"))
        if not rd:
            e["return_date"] = "Please choose a return date."
        if not rt:
            e["return_time"] = "Please choose a return time."
        if rd and rt:
            rdt = datetime.combine(rd, rt)
            if pdt and rdt <= pdt:
                e["return_date"] = "The return must be after the pickup."
            v["return_date"], v["return_time"] = rd.isoformat(), rt.strftime("%H:%M")
            v["return_dt"] = rdt.strftime("%Y-%m-%dT%H:%M")

    v["instructions"] = clean(form.get("instructions"), 1000)
    details = {}
    if v["booking_type"] == "passenger":
        n = parse_int(form.get("passengers"), 1, 100)
        if n is None:
            e["passengers"] = "Please enter the number of passengers (1-100)."
        vp = form.get("vehicle_pref")
        details = {"passengers": n, "luggage": clean(form.get("luggage"), 300),
                   "vehicle_pref": vp if vp in PASSENGER_VEHICLE_OPTIONS else "No preference",
                   "accessibility": clean(form.get("accessibility"), 500)}
    elif v["booking_type"] == "goods":
        desc = clean(form.get("goods_description"), 600)
        if len(desc) < 3:
            e["goods_description"] = "Please describe the goods to be transported."
        assist = form.get("assistance")
        if assist not in ("yes", "no"):
            e["assistance"] = "Please tell us whether loading/unloading assistance is required."
        details = {"description": desc, "quantity_dimensions": clean(form.get("goods_quantity"), 300),
                   "weight": clean(form.get("goods_weight"), 100), "loading": clean(form.get("loading"), 300),
                   "unloading": clean(form.get("unloading"), 300), "assistance": assist,
                   "handling": clean(form.get("handling"), 500)}
    v["details"] = details

    for k, msg in (("consent_terms", "You must agree to the Terms and Conditions."),
                   ("consent_estimate", "Please acknowledge that any quotation shown is an estimate."),
                   ("consent_comms", "Please consent to booking-related communications so we can contact you.")):
        v[k] = 1 if form.get(k) == "on" else 0
        if not v[k]:
            e[k] = msg

    photos = []
    if v["booking_type"] == "goods":
        uploads = [f for f in files.getlist("photos") if f and f.filename]
        if len(uploads) > 4:
            e["photos"] = "You can upload up to 4 photographs."
        else:
            limit = current_app.config["MAX_UPLOAD_MB"] * 1024 * 1024
            for f in uploads:
                data = f.read(limit + 1)
                if len(data) > limit:
                    e["photos"] = f"Each photograph must be under {current_app.config['MAX_UPLOAD_MB']} MB."
                    break
                ext = _sniff_image(data[:16])
                if not ext:
                    e["photos"] = "Photographs must be JPEG, PNG or WebP images."
                    break
                photos.append((ext, data))
    v["_photos"] = photos
    return v, e


@bp.post("/book")
def book_submit():
    draft = _load_draft()
    if not draft:
        flash("Your session expired. Please start again with a quote.", "error")
        return redirect(url_for("public.quote_page"))
    ctx = _draft_context(draft)
    if not ctx:
        flash("Your quotation has expired. Please calculate it again.", "error")
        return redirect(url_for("public.quote_page"))

    def rerender(form, errors):
        return render_template("book.html", ctx=ctx, draft=draft, form=form, errors=errors,
                               vehicle_options=PASSENGER_VEHICLE_OPTIONS,
                               form_ts=ser("form").dumps(time.time())), 422

    form = request.form
    if form.get("website"):  # honeypot: bots fill hidden fields
        return redirect(url_for("public.home"))
    try:
        age = time.time() - ser("form").loads(form.get("form_ts", ""), max_age=6 * 3600)
    except (BadSignature, SignatureExpired):
        age = None
    if age is None or age < 3:
        flash("That was submitted too quickly or the form expired. Please check your details and submit again.", "error")
        return rerender(form, {})
    if rate_limited("booking", 8, 3600):
        flash("Too many booking requests from your connection. Please try again later.", "error")
        return rerender(form, {})

    v, errors = validate_booking(form, ctx, draft, request.files)
    if errors:
        flash("Please correct the highlighted fields.", "error")
        return rerender(form, errors)

    db = get_db()
    s = get_settings()
    now = utc_now_iso()
    manual = ctx["payload"] is None
    pk, dk = ctx["pickup"], ctx["dest"]
    row = {
        "created_at": now, "updated_at": now, "status": "Pending Review",
        "booking_type": v["booking_type"], "customer_name": v["customer_name"], "mobile": v["mobile"],
        "email": v["email"], "contact_method": v["contact_method"],
        "pickup_address": v["pickup_address"], "pickup_lat": pk.get("lat"), "pickup_lng": pk.get("lng"),
        "pickup_place_id": pk.get("place_id"),
        "dest_address": v["dest_address"], "dest_lat": dk.get("lat"), "dest_lng": dk.get("lng"),
        "dest_place_id": dk.get("place_id"),
        "journey_type": v["journey_type"], "return_different": 1 if ctx["diff"] else 0,
        "pickup_date": v["pickup_date"], "pickup_time": v["pickup_time"],
        "return_date": v["return_date"], "return_time": v["return_time"],
        "pickup_dt": v["pickup_dt"], "return_dt": v["return_dt"],
        "details": json.dumps(v["details"]), "instructions": v["instructions"],
        "quote_mode": "manual" if manual else "auto",
        "consent_terms": v["consent_terms"], "consent_estimate": v["consent_estimate"],
        "consent_comms": v["consent_comms"], "consent_at": now, "client_ip_hash": ip_hash(),
    }
    if ctx.get("diff"):
        row.update(ret_pickup_address=ctx["ret_pickup"]["address"], ret_pickup_lat=ctx["ret_pickup"]["lat"],
                   ret_pickup_lng=ctx["ret_pickup"]["lng"], ret_dest_address=ctx["ret_dest"]["address"],
                   ret_dest_lat=ctx["ret_dest"]["lat"], ret_dest_lng=ctx["ret_dest"]["lng"])
    if not manual:
        # Price comes ONLY from the signed token, recomputed on the server. Client-sent prices are ignored.
        q = ctx["quote"]
        legs = ctx["payload"]["legs"]
        row.update(
            distance_km=q["total_distance_km"], leg_distances=json.dumps([l["m"] for l in legs]),
            route_ref="\n".join(maps.maps_directions_url(l["o"], l["d"]) for l in legs),
            first_multiplier=q["first_multiplier"], second_multiplier=q["second_multiplier"],
            first_result=q["legs"][0]["first_result"], return_rule=q["return_rule"],
            return_factor=q["return_factor"], formula_version=q["formula_version"],
            pricing_breakdown=json.dumps(q), estimated_price=q["total"], currency=q["currency"],
        )

    cols = ", ".join(row)
    marks = ", ".join("?" for _ in row)
    for _ in range(8):
        ref = new_reference(s["reference_prefix"])
        try:
            cur = db.execute(f"INSERT INTO bookings(reference, {cols}) VALUES(?, {marks})", (ref, *row.values()))
            break
        except Exception as exc:  # reference collision (UNIQUE) - retry
            if "UNIQUE" not in str(exc):
                raise
    else:
        abort(500)
    bid = cur.lastrowid

    saved = []
    for ext, data in v["_photos"]:
        name = f"{bid}_{secrets.token_hex(8)}.{ext}"
        with open(f"{current_app.config['UPLOAD_DIR']}/private/{name}", "wb") as fh:
            fh.write(data)
        saved.append(name)
    if saved:
        db.execute("UPDATE bookings SET photos=? WHERE id=?", (json.dumps(saved), bid))
    audit(bid, None, "created", f"Submitted online ({row['quote_mode']} quote)")
    db.execute("DELETE FROM drafts WHERE id=?", (session.pop("draft_id", ""),))
    db.commit()

    booking = db.execute("SELECT * FROM bookings WHERE id=?", (bid,)).fetchone()
    mailer.customer("received", booking)
    mailer.admin("new_manual_quote" if manual else "new_booking", booking)
    session["last_ref"] = ref
    session["verified"] = list({*session.get("verified", []), ref})[-20:]
    return redirect(url_for("public.submitted"))


@bp.get("/booking/submitted")
def submitted():
    ref = session.get("last_ref")
    if not ref:
        return redirect(url_for("public.home"))
    b = get_db().execute("SELECT * FROM bookings WHERE reference=?", (ref,)).fetchone()
    if not b:
        return redirect(url_for("public.home"))
    return render_template("submitted.html", b=b)


# =============================================================== status lookup
@bp.route("/booking-status", methods=["GET", "POST"])
def status_lookup():
    if request.method == "POST":
        if rate_limited("lookup", 10, 900):
            flash("Too many attempts. Please wait a few minutes and try again.", "error")
            return render_template("status_lookup.html"), 429
        ref = clean(request.form.get("reference"), 40).upper()
        email = clean(request.form.get("email"), 254).lower()
        b = get_db().execute("SELECT reference FROM bookings WHERE reference=? AND lower(email)=? AND anonymised_at IS NULL",
                             (ref, email)).fetchone()
        if b:
            session["verified"] = list({*session.get("verified", []), ref})[-20:]
            return redirect(url_for("public.status_view", ref=ref))
        flash("We could not find a booking with that reference and email address.", "error")
    return render_template("status_lookup.html")


def _verified_booking(ref):
    if ref not in session.get("verified", []):
        return None
    return get_db().execute("SELECT * FROM bookings WHERE reference=? AND anonymised_at IS NULL", (ref,)).fetchone()


@bp.get("/booking-status/<ref>")
def status_view(ref):
    b = _verified_booking(ref)
    if not b:
        flash("Please enter your booking reference and email address to view this booking.", "info")
        return redirect(url_for("public.status_lookup"))
    db = get_db()
    veh = db.execute("SELECT vehicle_type, name FROM vehicles WHERE id=?", (b["vehicle_id"],)).fetchone() if b["vehicle_id"] else None
    drv = db.execute("SELECT name FROM drivers WHERE id=?", (b["driver_id"],)).fetchone() if b["driver_id"] else None
    expired = bool(b["quote_expires_at"]) and b["quote_expires_at"] < now_fiji().date().isoformat()
    return render_template("status_view.html", b=b, veh=veh, drv=drv, quote_expired=expired,
                           details=json.loads(b["details"] or "{}"), terminal=b["status"] in TERMINAL)


@bp.post("/booking-status/<ref>/<action>")
def status_action(ref, action):
    b = _verified_booking(ref)
    if not b or action not in ("accept-quote", "decline-quote", "request-cancel", "request-reschedule"):
        abort(404)
    if rate_limited("status_action", 10, 3600):
        flash("Too many requests. Please try again later.", "error")
        return redirect(url_for("public.status_view", ref=ref))
    db = get_db()
    note = clean(request.form.get("message"), 500)
    if b["status"] in TERMINAL:
        flash("This booking is closed, so it can no longer be changed online.", "error")
        return redirect(url_for("public.status_view", ref=ref))
    if action in ("accept-quote", "decline-quote"):
        expired = bool(b["quote_expires_at"]) and b["quote_expires_at"] < now_fiji().date().isoformat()
        if b["quote_status"] != "sent" or expired:
            flash("There is no open quotation to respond to.", "error")
            return redirect(url_for("public.status_view", ref=ref))
        new = "accepted" if action == "accept-quote" else "rejected"
        db.execute("UPDATE bookings SET quote_status=?, updated_at=? WHERE id=?", (new, utc_now_iso(), b["id"]))
        audit(b["id"], None, f"customer_quote_{new}", note)
        db.commit()
        b2 = db.execute("SELECT * FROM bookings WHERE id=?", (b["id"],)).fetchone()
        mailer.admin("quote_accepted" if new == "accepted" else "quote_rejected", b2, note)
        flash("Thank you - we have recorded your response. Our team will confirm your booking." if new == "accepted"
              else "We have recorded that you declined the quotation.", "ok")
    else:
        kind = "cancel" if action == "request-cancel" else "reschedule"
        if kind == "reschedule" and not note:
            flash("Please tell us the new date and time you would like.", "error")
            return redirect(url_for("public.status_view", ref=ref))
        audit(b["id"], None, f"customer_request_{kind}", note)
        db.commit()
        mailer.admin("cancel_request" if kind == "cancel" else "reschedule_request", b, note)
        flash("Your request has been sent to our team. Your booking stays unchanged until we confirm it.", "ok")
    return redirect(url_for("public.status_view", ref=ref))
