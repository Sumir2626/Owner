/* Quote page: Google Maps (map, Places Autocomplete (New), reverse geocoding) + server-side quotation.
 *
 * IMPORTANT: this script never calculates a price. It only collects locations, asks the server
 * (/api/quote) for the distance and price, and displays what the server returns.
 * All text from the server is inserted with textContent (never innerHTML).
 */
(function () {
  'use strict';
  var root = document.getElementById('quote-app');
  if (!root) return;

  var cfg = {
    key: root.dataset.mapsKey || '',
    mapId: root.dataset.mapId || 'DEMO_MAP_ID',
    manual: root.dataset.manual === '1',
    csrf: root.dataset.csrf || ''
  };
  var FIJI_CENTRE = { lat: -17.75, lng: 178.0 };
  var LABELS = { from: 'Pickup location', to: 'Destination', rfrom: 'Return pickup location', rto: 'Return destination' };
  var PIN = { from: 'A', to: 'B', rfrom: 'C', rto: 'D' };
  var COLORS = { from: '#0e7c86', to: '#12304a', rfrom: '#f2a900', rto: '#b36b00' };

  var state = { type: root.dataset.preset || '', journey: 'one_way', retDiff: false,
                pts: { from: null, to: null, rfrom: null, rto: null }, active: 'from', seq: 0, timer: null,
                lastOk: null };
  var gm = { ready: false, map: null, markers: {}, lines: [], geocoder: null, lib: {} };

  function $(s) { return root.querySelector(s); }
  function all(s) { return Array.prototype.slice.call(root.querySelectorAll(s)); }
  function el(tag, props, kids) {
    var n = document.createElement(tag);
    Object.keys(props || {}).forEach(function (k) {
      if (k === 'text') n.textContent = props[k]; else if (k === 'class') n.className = props[k]; else n.setAttribute(k, props[k]);
    });
    (kids || []).forEach(function (c) { if (c) n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return n;
  }
  var panel = $('#quote-panel');

  // ------------------------------------------------------------------ simple controls
  all('input[name="booking_type"]').forEach(function (r) {
    if (r.value === state.type) r.checked = true;
    r.addEventListener('change', function () { state.type = r.value; refreshButtons(); });
  });
  all('input[name="journey_type"]').forEach(function (r) {
    r.addEventListener('change', function () {
      state.journey = r.value;
      $('#ret-diff-wrap').hidden = state.journey !== 'return';
      if (state.journey !== 'return') { state.retDiff = false; $('#ret-diff').checked = false; }
      toggleReturnFields();
      requestQuote();
    });
  });
  $('#ret-diff').addEventListener('change', function (e) { state.retDiff = e.target.checked; toggleReturnFields(); requestQuote(); });
  all('[data-pick]').forEach(function (b) { b.addEventListener('click', function () { setActive(b.dataset.pick); }); });
  all('[data-clear]').forEach(function (b) { b.addEventListener('click', function () { clearPoint(b.dataset.clear); }); });

  function toggleReturnFields() {
    var show = state.journey === 'return' && state.retDiff;
    all('.ret-loc').forEach(function (n) { n.hidden = !show; });
    if (!show) { clearPoint('rfrom', true); clearPoint('rto', true); }
  }

  function setActive(k) {
    state.active = k;
    all('.loc').forEach(function (n) { n.classList.toggle('is-active', n.dataset.key === k); });
    var hint = $('#map-hint');
    if (hint) hint.textContent = gm.ready ? 'Click the map to set: ' + LABELS[k] : '';
  }

  // ------------------------------------------------------------------ points
  function setPoint(k, p) {
    state.pts[k] = p;
    var s = $('#sel-' + k);
    s.textContent = 'Selected: ' + p.address;
    $('[data-clear="' + k + '"]').hidden = false;
    drawMarker(k, p);
    var order = ['from', 'to', 'rfrom', 'rto'];
    var next = order.filter(function (o) { return !state.pts[o] && !(o.charAt(0) === 'r' && !(state.journey === 'return' && state.retDiff)); })[0];
    setActive(next || k);
    fitAll();
    requestQuote();
  }
  function clearPoint(k, silent) {
    if (!state.pts[k]) return;
    state.pts[k] = null;
    $('#sel-' + k).textContent = '';
    $('[data-clear="' + k + '"]').hidden = true;
    if (gm.markers[k]) { gm.markers[k].map = null; delete gm.markers[k]; }
    if (!silent) { setActive(k); requestQuote(); }
  }
  function drawMarker(k, p) {
    if (!gm.ready) return;
    if (gm.markers[k]) gm.markers[k].map = null;
    var pin = new gm.lib.PinElement({ glyph: PIN[k], glyphColor: '#fff', background: COLORS[k], borderColor: '#12304a' });
    gm.markers[k] = new gm.lib.AdvancedMarkerElement({ map: gm.map, position: { lat: p.lat, lng: p.lng },
      content: pin.element || pin, title: LABELS[k] + ': ' + p.address });
  }
  function fitAll() {
    if (!gm.ready) return;
    var pts = Object.keys(state.pts).map(function (k) { return state.pts[k]; }).filter(Boolean);
    if (!pts.length) return;
    if (pts.length === 1) { gm.map.setCenter({ lat: pts[0].lat, lng: pts[0].lng }); gm.map.setZoom(13); return; }
    var b = new google.maps.LatLngBounds();
    pts.forEach(function (p) { b.extend({ lat: p.lat, lng: p.lng }); });
    gm.map.fitBounds(b, 60);
  }
  function clearLines() { gm.lines.forEach(function (l) { l.setMap(null); }); gm.lines = []; }

  // ------------------------------------------------------------------ quote request
  function needed() {
    var ok = state.pts.from && state.pts.to;
    if (state.journey === 'return' && state.retDiff) ok = ok && state.pts.rfrom && state.pts.rto;
    return !!ok;
  }
  function requestQuote() {
    clearTimeout(state.timer);
    state.lastOk = null;
    clearLines();
    if (!needed()) { showIdle(); return; }
    showLoading();
    state.timer = setTimeout(doQuote, 250);
  }
  function pt(p) { return { address: p.address, lat: p.lat, lng: p.lng, place_id: p.place_id || '' }; }
  function doQuote() {
    var seq = ++state.seq;
    var body = { journey_type: state.journey, origin: pt(state.pts.from), destination: pt(state.pts.to) };
    if (state.journey === 'return' && state.retDiff) {
      body.return_different = true; body.return_origin = pt(state.pts.rfrom); body.return_destination = pt(state.pts.rto);
    }
    fetch('/api/quote', { method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': cfg.csrf }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().catch(function () { return { ok: false, code: 'bad_response' }; }); })
      .then(function (data) {
        if (seq !== state.seq) return;          // a newer request superseded this one
        if (data.ok) { state.lastOk = data; showQuote(data); drawRoutes(data); }
        else showFailure(data);
      })
      .catch(function () {
        if (seq !== state.seq) return;
        showFailure({ message: 'We could not reach the server. No price has been calculated. Please check your connection and try again.', manual_allowed: cfg.manual });
      });
  }
  function drawRoutes(data) {
    if (!gm.ready || !gm.lib.geometry) return;
    clearLines();
    data.routes.forEach(function (r, i) {
      if (!r.polyline) return;
      var path = google.maps.geometry.encoding.decodePath(r.polyline);
      gm.lines.push(new google.maps.Polyline({ map: gm.map, path: path, strokeColor: i ? '#f2a900' : '#0e7c86', strokeWeight: 5, strokeOpacity: .9 }));
    });
  }

  // ------------------------------------------------------------------ panel rendering
  function showIdle() {
    panel.textContent = '';
    panel.appendChild(el('h2', { text: 'Your quotation' }));
    panel.appendChild(el('p', { class: 'muted', text: 'Choose your pickup location and destination. Your approximate quotation appears here automatically and updates whenever you change a location.' }));
  }
  function showLoading() {
    panel.textContent = '';
    panel.appendChild(el('h2', { text: 'Your quotation' }));
    panel.appendChild(el('p', {}, [el('span', { class: 'spinner', 'aria-hidden': 'true' }), 'Calculating the driving route and price...']));
  }
  function jtLabel(j) { return j === 'return' ? 'Return trip' : 'One-way trip'; }
  function row(dl, k, v) { dl.appendChild(el('dt', { text: k })); dl.appendChild(el('dd', { text: v })); }

  function showQuote(data) {
    var q = data.quote;
    panel.textContent = '';
    panel.appendChild(el('h2', { text: 'Your approximate quotation' }));

    panel.appendChild(el('h3', { text: 'Journey details' }));
    var dl = el('dl');
    row(dl, 'Pickup', state.pts.from.address);
    row(dl, 'Destination', state.pts.to.address);
    row(dl, 'Journey type', jtLabel(q.journey_type));
    row(dl, q.return_different ? 'Outbound driving distance' : 'One-way driving distance', q.legs[0].distance_km + ' km');
    if (q.return_different) {
      row(dl, 'Return pickup', state.pts.rfrom.address);
      row(dl, 'Return destination', state.pts.rto.address);
      row(dl, 'Return driving distance', q.legs[1].distance_km + ' km');
    }
    panel.appendChild(dl);
    if (data.maps_links && data.maps_links[0]) {
      panel.appendChild(el('p', { class: 'small' }, [el('a', { href: data.maps_links[0], target: '_blank', rel: 'noopener noreferrer', text: 'Open this route in Google Maps' })]));
    }

    panel.appendChild(el('h3', { text: 'Price calculation' }));
    var ul = el('ul', { class: 'calc' });
    q.lines.forEach(function (ln) {
      ul.appendChild(el('li', {}, [el('span', { class: 'lbl', text: ln.label }), el('span', { class: 'val', text: ln.text })]));
    });
    panel.appendChild(ul);
    panel.appendChild(el('div', { class: 'total' }, [el('span', { text: 'Approximate total (FJD)' }), el('span', { class: 'amt', text: q.total_display })]));
    if (q.note) panel.appendChild(el('p', { class: 'small muted', text: q.note }));

    var disc = $('#disclaimer-src');
    panel.appendChild(el('p', { class: 'disclaimer', text: disc ? disc.textContent.trim() : '' }));
    panel.appendChild(actionButtons(true));
    refreshButtons();
  }

  function showFailure(data) {
    panel.textContent = '';
    panel.appendChild(el('h2', { text: 'Your quotation' }));
    panel.appendChild(el('div', { class: 'notice bad', role: 'alert', text: data.message || 'We could not calculate a price for this journey.' }));
    if (data.manual_allowed) {
      panel.appendChild(el('p', { class: 'muted', text: (root.dataset.manualMsg || '') }));
      panel.appendChild(actionButtons(false));
    }
    refreshButtons();
  }

  function actionButtons(withProceed) {
    var wrap = el('div', { class: 'actions' });
    if (withProceed) wrap.appendChild(el('button', { type: 'button', class: 'btn', id: 'btn-proceed', text: 'Proceed to Booking' }));
    if (cfg.manual) wrap.appendChild(el('button', { type: 'button', class: 'btn btn-secondary', id: 'btn-manual', text: 'Request a Manual Quote' }));
    wrap.appendChild(el('p', { class: 'small muted', id: 'btn-hint', role: 'status' }));
    wrap.addEventListener('click', function (e) {
      if (e.target.id === 'btn-proceed') proceed('auto');
      if (e.target.id === 'btn-manual') proceed('manual');
    });
    return wrap;
  }
  function refreshButtons() {
    var p = $('#btn-proceed'), h = $('#btn-hint');
    if (p) p.setAttribute('aria-disabled', state.type ? 'false' : 'true');
    if (h) h.textContent = state.type ? '' : 'Please choose Passenger or Goods transport above first.';
  }

  function proceed(mode) {
    if (!state.type) {
      var h = $('#btn-hint'); if (h) h.textContent = 'Please choose Passenger or Goods transport above first.';
      $('#svc-fieldset').scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    var body = { mode: mode, booking_type: state.type, journey_type: state.journey };
    if (mode === 'auto') {
      if (!state.lastOk) return;
      body.token = state.lastOk.token;
    } else {
      var mf = $('#manual-from').value.trim(), mt = $('#manual-to').value.trim();
      var o = state.pts.from || (mf ? { address: mf } : null), d = state.pts.to || (mt ? { address: mt } : null);
      if (!o || !d) {
        var dt = $('#manual-details'); if (dt) dt.open = true;
        var hh = $('#btn-hint') || $('#manual-hint');
        if (hh) hh.textContent = 'Please enter your pickup location and destination first.';
        return;
      }
      body.origin = o; body.destination = d;
    }
    fetch('/book/start', { method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': cfg.csrf }, body: JSON.stringify(body) })
      .then(function (r) { return r.json(); })
      .then(function (d) { if (d.ok) location.href = d.redirect; else { var h = $('#btn-hint') || $('#manual-hint'); if (h) h.textContent = d.message || 'Please try again.'; } })
      .catch(function () { var h = $('#btn-hint') || $('#manual-hint'); if (h) h.textContent = 'Could not continue. Please try again.'; });
  }
  // Manual-entry button (always available, also when Maps is unavailable)
  var mb = $('#manual-go');
  if (mb) mb.addEventListener('click', function () { proceed('manual'); });

  // ------------------------------------------------------------------ Google Maps
  function mapsUnavailable(why) {
    var n = $('#maps-status');
    n.hidden = false;
    n.textContent = why;
    var dt = $('#manual-details'); if (dt) dt.open = true;
    all('.ac').forEach(function (a) { a.textContent = ''; });
    $('#map').hidden = true;
    var h = $('#map-hint'); if (h) h.hidden = true;
  }
  function loadGoogle() {
    return new Promise(function (resolve, reject) {
      if (window.google && google.maps && google.maps.importLibrary) return resolve();
      window.__gmReady = resolve;
      window.gm_authFailure = function () {
        mapsUnavailable('Google Maps could not be authorised for this website, so address search is unavailable. You can still request a manual quotation below.');
      };
      var s = document.createElement('script');
      s.src = 'https://maps.googleapis.com/maps/api/js?key=' + encodeURIComponent(cfg.key) +
              '&v=weekly&loading=async&language=en&region=FJ&callback=__gmReady';
      s.async = true; s.onerror = function () { reject(new Error('load')); };
      document.head.appendChild(s);
    });
  }
  function attachAutocomplete(k) {
    var host = $('#ac-' + k);
    if (!host) return;
    var ac = new gm.lib.PlaceAutocompleteElement({ includedRegionCodes: ['fj'] });
    ac.setAttribute('aria-label', LABELS[k] + ' search');
    host.textContent = '';
    host.appendChild(ac);
    ac.addEventListener('focusin', function () { setActive(k); });
    function handle(place) {
      return place.fetchFields({ fields: ['id', 'displayName', 'formattedAddress', 'location'] }).then(function () {
        if (!place.location) return;
        var name = place.displayName, addr = place.formattedAddress || '';
        setPoint(k, { address: (name && addr.indexOf(name) === -1 ? name + ', ' : '') + addr || name,
                      lat: place.location.lat(), lng: place.location.lng(), place_id: place.id || '' });
      });
    }
    // Event name is 'gmp-select' in current releases; 'gmp-placeselect' in older ones. Support both.
    ac.addEventListener('gmp-select', function (ev) { if (ev.placePrediction) handle(ev.placePrediction.toPlace()); });
    ac.addEventListener('gmp-placeselect', function (ev) { if (ev.place) handle(ev.place); });
  }
  function initMaps() {
    if (!cfg.key) { mapsUnavailable('Interactive maps are not enabled yet. Please enter your locations below to request a manual quotation.'); return; }
    loadGoogle().then(function () {
      return Promise.all([google.maps.importLibrary('maps'), google.maps.importLibrary('places'),
                          google.maps.importLibrary('marker'), google.maps.importLibrary('geocoding'),
                          google.maps.importLibrary('geometry')]);
    }).then(function (libs) {
      gm.lib = { Map: libs[0].Map, PlaceAutocompleteElement: libs[1].PlaceAutocompleteElement,
                 AdvancedMarkerElement: libs[2].AdvancedMarkerElement, PinElement: libs[2].PinElement,
                 Geocoder: libs[3].Geocoder, geometry: libs[4] };
      gm.map = new gm.lib.Map($('#map'), { center: FIJI_CENTRE, zoom: 7, mapId: cfg.mapId, mapTypeControl: false,
                                            streetViewControl: false, fullscreenControl: true, gestureHandling: 'cooperative',
                                            restriction: null });
      gm.geocoder = new gm.lib.Geocoder();
      gm.ready = true;
      ['from', 'to', 'rfrom', 'rto'].forEach(attachAutocomplete);
      gm.map.addListener('click', function (e) {
        var k = state.active, ll = e.latLng;
        if ((k === 'rfrom' || k === 'rto') && !(state.journey === 'return' && state.retDiff)) return;
        gm.geocoder.geocode({ location: ll }).then(function (res) {
          var r = res.results && res.results[0];
          setPoint(k, { address: r ? r.formatted_address : ll.lat().toFixed(5) + ', ' + ll.lng().toFixed(5),
                        lat: ll.lat(), lng: ll.lng(), place_id: r ? r.place_id : '' });
        }).catch(function () {
          setPoint(k, { address: ll.lat().toFixed(5) + ', ' + ll.lng().toFixed(5), lat: ll.lat(), lng: ll.lng(), place_id: '' });
        });
      });
      setActive('from');
    }).catch(function () {
      mapsUnavailable('Google Maps could not be loaded, so address search is unavailable. You can still request a manual quotation below.');
    });
  }

  showIdle();
  toggleReturnFields();
  initMaps();
})();
