(function () {
  'use strict';
  var form = document.getElementById('booking-form');
  if (!form) return;

  function chosen(name) {
    var r = form.querySelector('input[name="' + name + '"]:checked');
    return r ? r.value : '';
  }

  function sync() {
    var type = chosen('booking_type');
    form.setAttribute('data-type', type);
    // Required only on fields that are currently relevant (server still validates everything).
    form.querySelectorAll('[data-req-for]').forEach(function (el) {
      el.required = el.getAttribute('data-req-for') === type;
    });
    var jt = form.dataset.journey || chosen('journey_type');
    var ret = form.querySelector('#return-fields');
    if (ret) {
      ret.hidden = jt !== 'return';
      ret.querySelectorAll('input').forEach(function (i) { i.required = jt === 'return'; });
    }
  }

  form.querySelectorAll('input[name="booking_type"], input[name="journey_type"]').forEach(function (r) {
    r.addEventListener('change', sync);
  });

  // Earliest selectable date = today in Fiji
  try {
    var today = new Date().toLocaleDateString('en-CA', { timeZone: 'Pacific/Fiji' });
    form.querySelectorAll('input[type=date]').forEach(function (d) { d.min = today; });
  } catch (e) { /* older browsers: server validates anyway */ }

  sync();
})();
