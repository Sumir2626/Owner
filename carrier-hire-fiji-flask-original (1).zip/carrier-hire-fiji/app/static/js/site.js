(function () {
  'use strict';
  // Mobile navigation toggle
  var t = document.querySelector('.nav-toggle'), nav = document.getElementById('nav');
  if (t && nav) {
    t.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      t.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
  // Mark current page in nav
  document.querySelectorAll('#nav a, .admin-bar a').forEach(function (a) {
    if (a.getAttribute('href') === location.pathname) a.setAttribute('aria-current', 'page');
  });
  // Loading state on form submit (prevents double submission)
  document.querySelectorAll('form[data-loading]').forEach(function (f) {
    f.addEventListener('submit', function () {
      var b = f.querySelector('button[type=submit]');
      if (b && f.checkValidity()) { b.disabled = true; b.textContent = b.dataset.loading || 'Please wait...'; }
    });
  });
  // Confirm dangerous actions
  document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) { if (!window.confirm(f.dataset.confirm)) e.preventDefault(); });
  });
})();
