import hashlib
import hmac
import secrets
import time
from functools import wraps

from flask import abort, current_app, flash, g, jsonify, redirect, request, session, url_for

from .db import get_db
from .util import utc_now_iso


# ---------------------------------------------------------------- CSRF
def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]


def check_csrf():
    """Reject any state-changing request that lacks the session's CSRF token."""
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return None
    sent = request.headers.get("X-CSRF-Token") or request.form.get("csrf_token", "")
    expected = session.get("csrf", "")
    if not expected or not hmac.compare_digest(str(sent), expected):
        if request.path.startswith("/api/") or request.is_json:
            return jsonify(ok=False, code="csrf", message="Your session expired. Please refresh the page."), 400
        abort(400, "Security token missing or expired. Please go back, refresh the page and try again.")
    return None


# ---------------------------------------------------------------- rate limiting
def client_ip():
    return request.remote_addr or "0.0.0.0"


def ip_hash():
    """One-way hash so abuse can be traced without storing raw IPs in bookings."""
    return hashlib.sha256((current_app.config["SECRET_KEY"] + client_ip()).encode()).hexdigest()[:24]


def rate_limited(scope: str, limit: int, window_sec: int) -> bool:
    """Fixed-window counter per IP. Returns True when the caller is over the limit."""
    db = get_db()
    key = f"{scope}:{client_ip()}"
    start = int(time.time() // window_sec) * window_sec
    db.execute("INSERT INTO rate_limits(key, window_start, count) VALUES(?,?,1) "
               "ON CONFLICT(key, window_start) DO UPDATE SET count = count + 1", (key, start))
    count = db.execute("SELECT count FROM rate_limits WHERE key=? AND window_start=?", (key, start)).fetchone()[0]
    if secrets.randbelow(50) == 0:
        db.execute("DELETE FROM rate_limits WHERE window_start < ?", (int(time.time()) - 86400,))
    db.commit()
    return count > limit


# ---------------------------------------------------------------- auth
def load_user():
    g.user = None
    uid = session.get("uid")
    if uid:
        row = get_db().execute("SELECT * FROM users WHERE id=? AND active=1", (uid,)).fetchone()
        if row:
            g.user = row
        else:
            session.pop("uid", None)


def login_required(view):
    @wraps(view)
    def wrapped(*a, **kw):
        if g.get("user") is None:
            if request.method == "GET":
                return redirect(url_for("admin.login", next=request.path))
            abort(401)
        return view(*a, **kw)
    return wrapped


def role_required(*roles):
    def deco(view):
        @wraps(view)
        @login_required
        def wrapped(*a, **kw):
            if g.user["role"] not in roles:
                abort(403)
            return view(*a, **kw)
        return wrapped
    return deco


# ---------------------------------------------------------------- headers
def csp_nonce():
    """Per-request nonce. Only pages that load Google Maps ask for one (the quote page)."""
    if "csp_nonce" not in g:
        g.csp_nonce = secrets.token_urlsafe(16)
    return g.csp_nonce


STRICT_CSP = (
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
    "img-src 'self' data:; font-src 'self' https://fonts.gstatic.com; connect-src 'self'; "
    "frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
)


def maps_csp(nonce):
    """Google's recommended strict, nonce-based policy for the Maps JavaScript API
    (developers.google.com/maps/documentation/javascript/content-security-policy).
    Applied to the quote page only; every other page uses STRICT_CSP."""
    return (
        "default-src 'self'; "
        f"script-src 'nonce-{nonce}' 'strict-dynamic' 'self' https://maps.googleapis.com https://*.gstatic.com 'unsafe-eval' blob:; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "img-src 'self' data: blob: https://*.googleapis.com https://*.gstatic.com https://*.google.com "
        "https://*.ggpht.com https://*.googleusercontent.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "connect-src 'self' https://*.googleapis.com https://*.google.com https://*.gstatic.com data: blob:; "
        "frame-src https://*.google.com; worker-src blob:; object-src 'none'; base-uri 'self'; "
        "form-action 'self'; frame-ancestors 'none'"
    )


def add_security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    resp.headers.setdefault("Permissions-Policy", "geolocation=(), camera=(), microphone=()")
    resp.headers.setdefault("Content-Security-Policy",
                            maps_csp(g.csp_nonce) if g.get("csp_nonce") else STRICT_CSP)
    if current_app.config["SESSION_COOKIE_SECURE"]:
        resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    if request.path.startswith(("/admin", "/booking-status", "/book", "/api/")):
        resp.headers["Cache-Control"] = "no-store"
    return resp
