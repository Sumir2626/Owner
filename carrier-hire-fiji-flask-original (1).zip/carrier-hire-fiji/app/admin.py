import csv
import io
import json
import os
import re
import secrets
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from urllib.parse import urlparse

from flask import (Blueprint, abort, current_app, flash, g, redirect, render_template, request,
                   send_from_directory, session, url_for, Response)
from werkzeug.security import check_password_hash, generate_password_hash

from . import STATUSES, mailer, maps, pricing
from .db import audit, current_pricing, get_db, get_settings, set_settings
from .security import client_ip, login_required, rate_limited, role_required
from .util import (clean, now_fiji, parse_date, parse_int, parse_time, utc_now_iso, valid_email,
                   valid_phone)

bp = Blueprint("admin", __name__)

TRANSITIONS = {
    "Pending Review": ["Quotation Sent", "Confirmed", "Cancelled", "Rejected"],
    "Quotation Sent": ["Pending Review", "Confirmed", "Cancelled", "Rejected"],
    "Confirmed": ["Pending Review", "Cancelled"],            # 'Vehicle/Driver Assigned' only via Assign
    "Vehicle/Driver Assigned": ["Confirmed", "In Progress", "Cancelled"],
    "In Progress": ["Completed", "Cancelled"],
    "Completed": [], "Cancelled": [], "Rejected": [],
}
BLOCKING = ("Confirmed", "Vehicle/Driver Assigned", "In Progress")  # statuses that occupy a vehicle/driver
CONFIRMED_VALUE = ("Confirmed", "Vehicle/Driver Assigned", "In Progress", "Completed")
VEHICLE_TYPES = ["Car / sedan", "SUV", "Van / minivan", "Minibus", "Coach / bus", "Utility / pickup",
                 "Small truck", "Medium truck", "Large truck", "Flatbed / tipper", "Other"]
PER_PAGE = 25


# =================================================================== users
def create_user(email, name, role, password):
    email = clean(email, 254).lower()
    if not valid_email(email):
        return "Enter a valid email address."
    if len(clean(name, 100)) < 2:
        return "Enter a name."
    if role not in ("admin", "staff"):
        return "Invalid role."
    if len(password or "") < 12:
        return "Password must be at least 12 characters."
    db = get_db()
    if db.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
        return "That email already has an account."
    db.execute("INSERT INTO users(email,name,password_hash,role,created_at) VALUES(?,?,?,?,?)",
               (email, clean(name, 100), generate_password_hash(password), role, utc_now_iso()))
    db.commit()
    return None


_DUMMY_HASH = generate_password_hash("not-a-real-password")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("admin.dashboard"))
    if request.method == "POST":
        if rate_limited("login", 15, 900):
            flash("Too many sign-in attempts. Please wait 15 minutes.", "error")
            return render_template("admin/login.html"), 429
        email = clean(request.form.get("email"), 254).lower()
        pw = request.form.get("password", "")
        db = get_db()
        u = db.execute("SELECT * FROM users WHERE email=? AND active=1", (email,)).fetchone()
        now = utc_now_iso()
        if u and u["locked_until"] and u["locked_until"] > now:
            flash("This account is temporarily locked. Try again later.", "error")
        elif u and check_password_hash(u["password_hash"], pw):
            db.execute("UPDATE users SET failed_logins=0, locked_until=NULL, last_login=? WHERE id=?", (now, u["id"]))
            db.commit()
            session.clear()           # defeat session fixation
            session["uid"] = u["id"]
            session.permanent = True
            nxt = request.args.get("next", "")
            if not (nxt.startswith("/admin") and not urlparse(nxt).netloc):
                nxt = url_for("admin.dashboard")
            return redirect(nxt)
        else:
            if u:
                fails = u["failed_logins"] + 1
                lock = (datetime.now(timezone.utc) + timedelta(minutes=15)).replace(microsecond=0).isoformat() if fails >= 5 else None
                db.execute("UPDATE users SET failed_logins=?, locked_until=? WHERE id=?", (0 if lock else fails, lock, u["id"]))
                db.commit()
            else:
                check_password_hash(_DUMMY_HASH, pw)  # equalise timing
            flash("Incorrect email or password.", "error")
    return render_template("admin/login.html")


@bp.post("/logout")
def logout():
    session.clear()
    flash("You have been signed out.", "ok")
    return redirect(url_for("admin.login"))


@bp.route("/account", methods=["GET", "POST"])
@login_required
def account():
    if request.method == "POST":
        cur, new, new2 = request.form.get("current", ""), request.form.get("new", ""), request.form.get("new2", "")
        if not check_password_hash(g.user["password_hash"], cur):
            flash("Current password is incorrect.", "error")
        elif len(new) < 12:
            flash("New password must be at least 12 characters.", "error")
        elif new != new2:
            flash("New passwords do not match.", "error")
        else:
            db = get_db()
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), g.user["id"]))
            db.commit()
            flash("Password changed.", "ok")
            return redirect(url_for("admin.account"))
    return render_template("admin/account.html")


@bp.route("/users", methods=["GET", "POST"])
@role_required("admin")
def users():
    db = get_db()
    if request.method == "POST":
        err = create_user(request.form.get("email"), request.form.get("name"),
                          request.form.get("role"), request.form.get("password"))
        flash(err or "Account created.", "error" if err else "ok")
        return redirect(url_for("admin.users"))
    return render_template("admin/users.html", rows=db.execute("SELECT * FROM users ORDER BY created_at").fetchall())


@bp.post("/users/<int:uid>/toggle")
@role_required("admin")
def user_toggle(uid):
    db = get_db()
    u = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone() or abort(404)
    if u["id"] == g.user["id"]:
        flash("You cannot deactivate your own account.", "error")
    else:
        db.execute("UPDATE users SET active=?, failed_logins=0, locked_until=NULL WHERE id=?", (0 if u["active"] else 1, uid))
        db.commit()
        flash("Account updated.", "ok")
    return redirect(url_for("admin.users"))


@bp.post("/users/<int:uid>/reset")
@role_required("admin")
def user_reset(uid):
    pw = request.form.get("password", "")
    if len(pw) < 12:
        flash("Password must be at least 12 characters.", "error")
    else:
        db = get_db()
        db.execute("UPDATE users SET password_hash=?, failed_logins=0, locked_until=NULL WHERE id=?",
                   (generate_password_hash(pw), uid))
        db.commit()
        flash("Password reset.", "ok")
    return redirect(url_for("admin.users"))


# =================================================================== dashboard & list
@bp.get("/")
@login_required
def dashboard():
    db = get_db()
    counts = {r["status"]: r["n"] for r in db.execute("SELECT status, COUNT(*) n FROM bookings GROUP BY status")}
    pending = db.execute("SELECT * FROM bookings WHERE status='Pending Review' ORDER BY created_at LIMIT 10").fetchall()
    accepted = db.execute("SELECT * FROM bookings WHERE quote_status='accepted' AND status='Quotation Sent' ORDER BY updated_at").fetchall()
    today = now_fiji().strftime("%Y-%m-%dT00:00")
    soon = (now_fiji() + timedelta(days=7)).strftime("%Y-%m-%dT23:59")
    upcoming = db.execute("SELECT * FROM bookings WHERE status IN ('Confirmed','Vehicle/Driver Assigned') "
                          "AND pickup_dt BETWEEN ? AND ? ORDER BY pickup_dt", (today, soon)).fetchall()
    requests_ = db.execute("SELECT h.*, b.reference, b.id AS bid FROM booking_history h JOIN bookings b ON b.id=h.booking_id "
                           "WHERE h.action LIKE 'customer_request_%' AND b.status NOT IN ('Completed','Cancelled','Rejected') "
                           "ORDER BY h.id DESC LIMIT 8").fetchall()
    unassigned = db.execute("SELECT COUNT(*) FROM bookings WHERE status='Confirmed'").fetchone()[0]
    enq = db.execute("SELECT COUNT(*) FROM enquiries WHERE status='new'").fetchone()[0]
    return render_template("admin/dashboard.html", counts=counts, pending=pending, accepted=accepted,
                           upcoming=upcoming, requests=requests_, unassigned=unassigned, new_enquiries=enq)


def _filters(args):
    where, params = ["1=1"], []
    q = clean(args.get("q"), 100)
    if q:
        where.append("(reference LIKE ? OR customer_name LIKE ? OR dest_address LIKE ? OR pickup_address LIKE ?)")
        params += [f"%{q}%"] * 4
    if args.get("status") in STATUSES:
        where.append("status=?"); params.append(args["status"])
    if args.get("type") in ("passenger", "goods"):
        where.append("booking_type=?"); params.append(args["type"])
    if parse_date(args.get("date_from")):
        where.append("pickup_date>=?"); params.append(args["date_from"])
    if parse_date(args.get("date_to")):
        where.append("pickup_date<=?"); params.append(args["date_to"])
    return " AND ".join(where), params


@bp.get("/bookings")
@login_required
def bookings():
    db = get_db()
    where, params = _filters(request.args)
    page = max(1, parse_int(request.args.get("page"), 1, 100000) or 1)
    total = db.execute(f"SELECT COUNT(*) FROM bookings WHERE {where}", params).fetchone()[0]
    rows = db.execute(f"SELECT * FROM bookings WHERE {where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
                      (*params, PER_PAGE, (page - 1) * PER_PAGE)).fetchall()
    qs = {k: v for k, v in request.args.items() if k != "page" and v}
    return render_template("admin/bookings.html", rows=rows, total=total, page=page,
                           pages=max(1, -(-total // PER_PAGE)), qs=qs)


# =================================================================== booking detail
def _booking(bid):
    b = get_db().execute("SELECT * FROM bookings WHERE id=?", (bid,)).fetchone()
    return b or abort(404)


def _window(pickup_dt, return_dt, hours):
    start = datetime.fromisoformat(pickup_dt)
    end = (datetime.fromisoformat(return_dt) if return_dt else start) + timedelta(hours=hours)
    return start, end


def find_conflicts(db, booking, vehicle_id=None, driver_id=None, pickup_dt=None, return_dt=None):
    hours = int(get_settings()["default_job_hours"])
    s1, e1 = _window(pickup_dt or booking["pickup_dt"], return_dt if pickup_dt else booking["return_dt"], hours)
    out = []
    for kind, col, val in (("vehicle", "vehicle_id", vehicle_id), ("driver", "driver_id", driver_id)):
        if not val:
            continue
        for o in db.execute(f"SELECT * FROM bookings WHERE {col}=? AND id!=? AND status IN ({','.join('?' * len(BLOCKING))})",
                            (val, booking["id"], *BLOCKING)):
            s2, e2 = _window(o["pickup_dt"], o["return_dt"], hours)
            if s1 < e2 and s2 < e1:
                out.append((kind, o))
    return out


def _vehicle_rows(db):
    rows = db.execute("SELECT v.*, d.name AS driver_name FROM vehicles v "
                      "LEFT JOIN drivers d ON d.id=v.default_driver_id WHERE v.active=1 ORDER BY v.vehicle_type, v.reg_no").fetchall()
    return [(r, r["status"] == "available" and bool(r["availability_checked_at"])) for r in rows]


@bp.get("/bookings/<int:bid>")
@login_required
def booking(bid):
    db = get_db()
    b = _booking(bid)
    notes = db.execute("SELECT n.*, u.name AS who FROM booking_notes n LEFT JOIN users u ON u.id=n.user_id "
                       "WHERE booking_id=? ORDER BY n.id DESC", (bid,)).fetchall()
    hist = db.execute("SELECT h.*, u.name AS who FROM booking_history h LEFT JOIN users u ON u.id=h.user_id "
                      "WHERE booking_id=? ORDER BY h.id DESC", (bid,)).fetchall()
    links = []
    if b["pickup_lat"] is not None:
        links.append(maps.maps_directions_url({"lat": b["pickup_lat"], "lng": b["pickup_lng"]},
                                              {"lat": b["dest_lat"], "lng": b["dest_lng"]}))
    else:
        links.append(maps.maps_directions_url({"address": b["pickup_address"]}, {"address": b["dest_address"]}))
    if b["return_different"] and b["ret_pickup_lat"] is not None:
        links.append(maps.maps_directions_url({"lat": b["ret_pickup_lat"], "lng": b["ret_pickup_lng"]},
                                              {"lat": b["ret_dest_lat"], "lng": b["ret_dest_lng"]}))
    allowed = [s for s in TRANSITIONS[b["status"]] if s != "Vehicle/Driver Assigned"]
    drivers = db.execute("SELECT * FROM drivers WHERE status='active' ORDER BY name").fetchall()
    return render_template(
        "admin/booking.html", b=b, notes=notes, hist=hist, links=links, allowed=allowed,
        details=json.loads(b["details"] or "{}"), breakdown=json.loads(b["pricing_breakdown"] or "null"),
        photos=json.loads(b["photos"] or "[]"), vehicles=_vehicle_rows(db), drivers=drivers,
        can_assign=b["status"] in ("Confirmed", "Vehicle/Driver Assigned"),
    )


@bp.get("/bookings/<int:bid>/photo/<name>")
@login_required
def booking_photo(bid, name):
    b = _booking(bid)
    if name not in json.loads(b["photos"] or "[]"):
        abort(404)
    return send_from_directory(f"{current_app.config['UPLOAD_DIR']}/private", name)


def _touch(bid):
    get_db().execute("UPDATE bookings SET updated_at=? WHERE id=?", (utc_now_iso(), bid))


def _decimal_money(text):
    try:
        d = Decimal(str(text).replace(",", "").replace("FJ$", "").strip())
    except (InvalidOperation, ValueError):
        return None
    if not d.is_finite() or d < 0 or d > Decimal("10000000"):
        return None
    return pricing.money(d)


def send_quotation(b, expires=None):
    db = get_db()
    days = int(get_settings()["quote_valid_days"])
    exp = expires or (now_fiji().date() + timedelta(days=days)).isoformat()
    new_status = "Quotation Sent" if b["status"] in ("Pending Review", "Quotation Sent") else b["status"]
    db.execute("UPDATE bookings SET quote_status='sent', quote_issued_at=?, quote_expires_at=?, status=?, updated_at=? WHERE id=?",
               (utc_now_iso(), exp, new_status, utc_now_iso(), b["id"]))
    audit(b["id"], g.user["id"], "quotation_sent", f"Final quotation {b['final_quote']} FJD, valid until {exp}")
    db.commit()
    mailer.customer("quote_sent", _booking(b["id"]))


@bp.post("/bookings/<int:bid>/quote")
@login_required
def booking_quote(bid):
    db = get_db()
    b = _booking(bid)
    action = request.form.get("action")
    uid = g.user["id"]
    if action in ("mark_accepted", "mark_rejected", "mark_expired"):
        new = action.split("_")[1]
        db.execute("UPDATE bookings SET quote_status=?, updated_at=? WHERE id=?", (new, utc_now_iso(), bid))
        audit(bid, uid, f"quote_marked_{new}", clean(request.form.get("reason"), 300))
        db.commit()
        flash(f"Quotation marked as {new}.", "ok")
        return redirect(url_for("admin.booking", bid=bid))

    if action == "use_estimate":
        if not b["estimated_price"]:
            flash("There is no system estimate for this booking. Enter the quotation manually.", "error")
            return redirect(url_for("admin.booking", bid=bid))
        final = Decimal(b["estimated_price"])
        reason = "System estimate accepted as the final price"
    else:
        final = _decimal_money(request.form.get("final_quote"))
        reason = clean(request.form.get("reason"), 500)
        if final is None:
            flash("Enter the final agreed quotation as a valid amount in FJD.", "error")
            return redirect(url_for("admin.booking", bid=bid))
        if b["estimated_price"] and final != Decimal(b["estimated_price"]) and not reason:
            flash("Please record the reason the final price differs from the estimate.", "error")
            return redirect(url_for("admin.booking", bid=bid))
    exp = request.form.get("expires")
    if exp and not parse_date(exp):
        flash("Enter a valid expiry date.", "error")
        return redirect(url_for("admin.booking", bid=bid))
    qs = b["quote_status"]
    if qs == "none" or (qs in ("sent", "accepted", "rejected", "expired") and f"{final:.2f}" != (b["final_quote"] or "")):
        qs = "draft"
    old = b["final_quote"]
    db.execute("UPDATE bookings SET final_quote=?, final_quote_reason=?, quote_expires_at=?, quote_status=?, updated_at=? WHERE id=?",
               (f"{final:.2f}", reason, exp or b["quote_expires_at"], qs, utc_now_iso(), bid))
    audit(bid, uid, "final_quote_set",
          f"Final quotation {old or '-'} -> {final:.2f} FJD (original estimate {b['estimated_price'] or 'none'} kept). {reason}")
    db.commit()
    if action == "send":
        send_quotation(_booking(bid), exp or None)
        flash("Quotation saved and emailed to the customer.", "ok")
    else:
        flash("Final quotation saved. It has not been sent to the customer yet.", "ok")
    return redirect(url_for("admin.booking", bid=bid))


@bp.post("/bookings/<int:bid>/status")
@login_required
def booking_status(bid):
    db = get_db()
    b = _booking(bid)
    new = request.form.get("status")
    reason = clean(request.form.get("reason"), 500)
    if new not in TRANSITIONS.get(b["status"], []) or new == "Vehicle/Driver Assigned":
        flash(f"A booking cannot move from '{b['status']}' to '{new}'.", "error")
        return redirect(url_for("admin.booking", bid=bid))
    if new in ("Cancelled", "Rejected") and not reason:
        flash("Please record a reason.", "error")
        return redirect(url_for("admin.booking", bid=bid))
    if new in ("Quotation Sent", "Confirmed") and not b["final_quote"]:
        flash("Record the final agreed quotation first (use 'Use estimate as final price' if the estimate is acceptable).", "error")
        return redirect(url_for("admin.booking", bid=bid))
    if new == "Confirmed" and b["quote_status"] == "rejected":
        flash("The customer declined the quotation. Issue a new quotation before confirming.", "error")
        return redirect(url_for("admin.booking", bid=bid))
    if new == "Quotation Sent":
        send_quotation(b)
        flash("Quotation sent.", "ok")
        return redirect(url_for("admin.booking", bid=bid))

    extra = ""
    sets = "status=?, updated_at=?"
    args = [new, utc_now_iso()]
    if new == "Confirmed" and b["status"] == "Vehicle/Driver Assigned":
        sets += ", vehicle_id=NULL, driver_id=NULL"
    if new == "Confirmed" and b["quote_status"] in ("draft", "sent", "none"):
        pass
    db.execute(f"UPDATE bookings SET {sets} WHERE id=?", (*args, bid))
    audit(bid, g.user["id"], "status_changed", f"{b['status']} -> {new}. {reason}")
    db.commit()
    nb = _booking(bid)
    if request.form.get("share_reason") and reason:
        extra = f"Note from our team: {reason}"
    kind = {"Confirmed": "confirmed", "Cancelled": "cancelled", "Rejected": "rejected", "Completed": "completed"}.get(new)
    if kind:
        mailer.customer(kind, nb, extra)
    flash(f"Status updated to {new}.", "ok")
    return redirect(url_for("admin.booking", bid=bid))


@bp.post("/bookings/<int:bid>/assign")
@login_required
def booking_assign(bid):
    db = get_db()
    b = _booking(bid)
    if b["status"] not in ("Confirmed", "Vehicle/Driver Assigned"):
        flash("Only confirmed bookings can have a vehicle assigned.", "error")
        return redirect(url_for("admin.booking", bid=bid))
    vid, did = parse_int(request.form.get("vehicle_id"), 1, 10**9), parse_int(request.form.get("driver_id"), 1, 10**9)
    if not vid:
        db.execute("UPDATE bookings SET vehicle_id=NULL, driver_id=NULL, status='Confirmed', updated_at=? WHERE id=?",
                   (utc_now_iso(), bid))
        audit(bid, g.user["id"], "unassigned", "Vehicle and driver removed")
        db.commit()
        flash("Vehicle and driver unassigned.", "ok")
        return redirect(url_for("admin.booking", bid=bid))
    v = db.execute("SELECT * FROM vehicles WHERE id=? AND active=1", (vid,)).fetchone()
    if not v:
        abort(404)
    if v["status"] != "available" or not v["availability_checked_at"]:
        flash("That vehicle's availability has not been recorded as 'available' and checked, so it cannot be assigned.", "error")
        return redirect(url_for("admin.booking", bid=bid))
    drv = None
    if did:
        drv = db.execute("SELECT * FROM drivers WHERE id=? AND status='active'", (did,)).fetchone()
        if not drv:
            flash("That driver is not active.", "error")
            return redirect(url_for("admin.booking", bid=bid))
    problems = []
    det = json.loads(b["details"] or "{}")
    if b["booking_type"] == "passenger" and det.get("passengers") and v["passenger_capacity"] \
            and det["passengers"] > v["passenger_capacity"]:
        problems.append(f"{v['reg_no']} seats {v['passenger_capacity']} but the booking has {det['passengers']} passengers.")
    for kind, o in find_conflicts(db, b, vid, did):
        problems.append(f"The {kind} is already assigned to booking {o['reference']} ({o['pickup_dt'].replace('T', ' ')}).")
    if problems:
        override = request.form.get("override") == "on" and g.user["role"] == "admin"
        why = clean(request.form.get("override_reason"), 300)
        if not (override and why):
            flash("Assignment blocked: " + " ".join(problems) +
                  (" Only an administrator can override this, with a recorded reason." if g.user["role"] != "admin" else
                   " To override, tick the override box and record a reason."), "error")
            return redirect(url_for("admin.booking", bid=bid))
        audit(bid, g.user["id"], "assignment_override", f"{' '.join(problems)} Reason: {why}")
    db.execute("UPDATE bookings SET vehicle_id=?, driver_id=?, status='Vehicle/Driver Assigned', updated_at=? WHERE id=?",
               (vid, did, utc_now_iso(), bid))
    audit(bid, g.user["id"], "assigned", f"Vehicle {v['reg_no']}" + (f", driver {drv['name']}" if drv else ""))
    db.commit()
    flash("Vehicle assigned.", "ok")
    return redirect(url_for("admin.booking", bid=bid))


@bp.post("/bookings/<int:bid>/reschedule")
@login_required
def booking_reschedule(bid):
    db = get_db()
    b = _booking(bid)
    if b["status"] in ("Completed", "Cancelled", "Rejected"):
        flash("A closed booking cannot be rescheduled.", "error")
        return redirect(url_for("admin.booking", bid=bid))
    pd, pt = parse_date(request.form.get("pickup_date")), parse_time(request.form.get("pickup_time"))
    reason = clean(request.form.get("reason"), 300)
    if not (pd and pt) or not reason:
        flash("Enter the new pickup date, time and a reason.", "error")
        return redirect(url_for("admin.booking", bid=bid))
    pdt = datetime.combine(pd, pt)
    rdt = rd = rt = None
    if b["journey_type"] == "return":
        rd, rt = parse_date(request.form.get("return_date")), parse_time(request.form.get("return_time"))
        if not (rd and rt) or datetime.combine(rd, rt) <= pdt:
            flash("Enter a return date and time after the pickup.", "error")
            return redirect(url_for("admin.booking", bid=bid))
        rdt = datetime.combine(rd, rt)
    new_p, new_r = pdt.strftime("%Y-%m-%dT%H:%M"), rdt.strftime("%Y-%m-%dT%H:%M") if rdt else None
    if b["vehicle_id"] or b["driver_id"]:
        conflicts = find_conflicts(db, b, b["vehicle_id"], b["driver_id"], new_p, new_r)
        if conflicts:
            flash("Rescheduling would double-book the assigned vehicle/driver with " +
                  ", ".join(o["reference"] for _, o in conflicts) + ". Unassign first or choose another time.", "error")
            return redirect(url_for("admin.booking", bid=bid))
    db.execute("UPDATE bookings SET pickup_date=?, pickup_time=?, pickup_dt=?, return_date=?, return_time=?, return_dt=?, updated_at=? WHERE id=?",
               (pd.isoformat(), pt.strftime("%H:%M"), new_p, rd.isoformat() if rd else None,
                rt.strftime("%H:%M") if rt else None, new_r, utc_now_iso(), bid))
    audit(bid, g.user["id"], "rescheduled", f"{b['pickup_dt']} -> {new_p}. {reason}")
    db.commit()
    mailer.customer("rescheduled", _booking(bid), f"Reason: {reason}" if request.form.get("share_reason") else "")
    flash("Booking rescheduled and the customer has been notified.", "ok")
    return redirect(url_for("admin.booking", bid=bid))


@bp.post("/bookings/<int:bid>/note")
@login_required
def booking_note(bid):
    _booking(bid)
    note = clean(request.form.get("note"), 1000)
    if note:
        db = get_db()
        db.execute("INSERT INTO booking_notes(booking_id,user_id,note,created_at) VALUES(?,?,?,?)",
                   (bid, g.user["id"], note, utc_now_iso()))
        audit(bid, g.user["id"], "note_added", "")
        db.commit()
    return redirect(url_for("admin.booking", bid=bid))


@bp.post("/bookings/<int:bid>/payment")
@role_required("admin")
def booking_payment(bid):
    st = request.form.get("payment_status")
    if st not in ("not_tracked", "unpaid", "deposit_received", "paid", "refunded"):
        abort(400)
    db = get_db()
    db.execute("UPDATE bookings SET payment_status=?, updated_at=? WHERE id=?", (st, utc_now_iso(), bid))
    audit(bid, g.user["id"], "payment_status", st)
    db.commit()
    return redirect(url_for("admin.booking", bid=bid))


# =================================================================== pricing
def _parse_extras(text):
    out = []
    for line in (text or "").splitlines():
        if not line.strip():
            continue
        if "|" not in line:
            raise ValueError(f"Additional charge '{line.strip()[:30]}' must look like: Label | amount")
        label, amt = (p.strip() for p in line.split("|", 1))
        d = _decimal_money(amt)
        if not label or len(label) > 60 or d is None or d > 100000:
            raise ValueError(f"Invalid additional charge line: {line.strip()[:40]}")
        out.append({"label": label, "amount": f"{d:.2f}"})
    if len(out) > 10:
        raise ValueError("At most 10 additional charges.")
    return out


@bp.route("/pricing", methods=["GET", "POST"])
@role_required("admin")
def pricing_settings():
    db = get_db()
    if request.method == "POST":
        try:
            if not check_password_hash(g.user["password_hash"], request.form.get("password", "")):
                raise ValueError("Your password is incorrect. Pricing changes need password confirmation.")
            m1 = pricing.parse_multiplier(request.form.get("first"), "First multiplier")
            m2 = pricing.parse_multiplier(request.form.get("second"), "Second multiplier")
            rule = request.form.get("return_rule")
            if rule not in pricing.RETURN_RULES:
                raise ValueError("Choose a return-trip rule.")
            factor = pricing.parse_multiplier(request.form.get("return_factor") or "2", "Return factor")
            extras = _parse_extras(request.form.get("extras"))
            note = clean(request.form.get("note"), 300)
            if not note:
                raise ValueError("Please record why the pricing is changing.")
        except ValueError as exc:
            flash(str(exc), "error")
        else:
            cur = db.execute("INSERT INTO pricing_versions(first_multiplier,second_multiplier,return_rule,return_factor,"
                             "extra_charges,note,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)",
                             (pricing.plain(m1), pricing.plain(m2), rule, pricing.plain(factor), json.dumps(extras),
                              note, g.user["id"], utc_now_iso()))
            db.commit()
            flash(f"Pricing saved as version PV{cur.lastrowid}. It applies to NEW quotations only; "
                  "existing bookings keep their original calculation.", "ok")
            return redirect(url_for("admin.pricing_settings"))
    cfg = current_pricing()
    examples = [pricing.build_quote([km * 1000], "one_way", cfg) for km in (10, 25, 50, 100, 200, 300)]
    versions = db.execute("SELECT p.*, u.name AS who FROM pricing_versions p LEFT JOIN users u ON u.id=p.created_by "
                          "ORDER BY p.id DESC LIMIT 20").fetchall()
    return render_template("admin/pricing.html", cfg=cfg, examples=examples, versions=versions,
                           rules=pricing.RETURN_RULES, extras_text="\n".join(f"{l} | {a}" for l, a in cfg.extras))


@bp.post("/pricing/manual")
@role_required("admin")
def pricing_manual():
    set_settings({"manual_quote_enabled": "1" if request.form.get("manual_quote_enabled") else "0",
                  "manual_quote_message": clean(request.form.get("manual_quote_message"), 400)})
    flash("Manual quotation settings saved.", "ok")
    return redirect(url_for("admin.pricing_settings"))


# =================================================================== business settings
BUSINESS_FIELDS = [
    # key, label, kind, maxlen
    ("business_name", "Business name", "text", 100), ("tagline", "Tagline", "text", 160),
    ("phone", "Telephone", "text", 24), ("whatsapp", "WhatsApp number (international, e.g. +679...)", "text", 24),
    ("email", "Public contact email", "email", 254), ("address", "Address", "area", 300),
    ("operating_hours", "Operating hours", "area", 400), ("service_areas", "Service areas (one per line)", "area", 1000),
    ("about_text", "About Us text", "area", 5000), ("terms_text", "Terms and Conditions", "area", 20000),
    ("privacy_text", "Privacy Policy", "area", 20000), ("cancellation_text", "Cancellation and refund policy", "area", 5000),
    ("faq_text", "FAQ (question line, then answer lines; blank line between items)", "area", 10000),
    ("testimonials_text", "Genuine testimonials only (one per line: Name | quote)", "area", 3000),
    ("reference_prefix", "Booking reference prefix (letters/digits, max 6)", "text", 6),
]
OPS_FIELDS = [
    ("admin_notify_email", "Send administrator notifications to", "email", 254),
    ("quote_valid_days", "Quotations valid for (days)", "int:1:90", 3),
    ("default_job_hours", "Default job length used for vehicle clash checks (hours)", "int:1:72", 3),
    ("retention_days", "Anonymise finished bookings after (days)", "int:30:3650", 4),
]


@bp.route("/business", methods=["GET", "POST"])
@role_required("admin")
def business():
    if request.method == "POST":
        vals, errs = {}, []
        for key, label, kind, n in BUSINESS_FIELDS + OPS_FIELDS:
            v = request.form.get(key, "")
            v = v.strip()[:n] if kind == "area" else clean(v, n)
            if kind == "email" and v and not valid_email(v):
                errs.append(f"{label}: invalid email.")
            if kind.startswith("int"):
                _, lo, hi = kind.split(":")
                if parse_int(v, int(lo), int(hi)) is None:
                    errs.append(f"{label}: enter a whole number between {lo} and {hi}.")
            if key in ("phone", "whatsapp") and v and not valid_phone(v):
                errs.append(f"{label}: invalid phone number.")
            vals[key] = v
        vals["reference_prefix"] = re.sub(r"[^A-Za-z0-9]", "", vals.get("reference_prefix", "")).upper() or "CH"
        vals["notify_customer_enabled"] = "1" if request.form.get("notify_customer_enabled") else "0"
        vals["notify_admin_enabled"] = "1" if request.form.get("notify_admin_enabled") else "0"
        logo = request.files.get("logo")
        if logo and logo.filename:
            from .public import _sniff_image
            data = logo.read(2 * 1024 * 1024 + 1)
            ext = _sniff_image(data[:16])
            if len(data) > 2 * 1024 * 1024 or not ext:
                errs.append("Logo must be a JPEG, PNG or WebP image under 2 MB.")
            else:
                name = f"logo_{secrets.token_hex(6)}.{ext}"
                with open(f"{current_app.config['UPLOAD_DIR']}/public/{name}", "wb") as fh:
                    fh.write(data)
                vals["logo_path"] = name
        if request.form.get("remove_logo"):
            vals["logo_path"] = ""
        if errs:
            for e in errs:
                flash(e, "error")
        else:
            set_settings(vals)
            flash("Business settings saved.", "ok")
            return redirect(url_for("admin.business"))
    return render_template("admin/business.html", fields=BUSINESS_FIELDS, ops=OPS_FIELDS)


# =================================================================== vehicles & drivers
@bp.get("/vehicles")
@login_required
def vehicles():
    rows = get_db().execute("SELECT v.*, d.name AS driver_name FROM vehicles v LEFT JOIN drivers d ON d.id=v.default_driver_id "
                            "ORDER BY v.active DESC, v.vehicle_type, v.reg_no").fetchall()
    return render_template("admin/vehicles.html", rows=rows)


@bp.route("/vehicles/new", methods=["GET", "POST"])
@bp.route("/vehicles/<int:vid>", methods=["GET", "POST"])
@login_required
def vehicle_form(vid=None):
    db = get_db()
    v = db.execute("SELECT * FROM vehicles WHERE id=?", (vid,)).fetchone() if vid else None
    if vid and not v:
        abort(404)
    drivers = db.execute("SELECT * FROM drivers ORDER BY name").fetchall()
    if request.method == "POST":
        f = request.form
        reg = clean(f.get("reg_no"), 20).upper()
        vtype = f.get("vehicle_type") if f.get("vehicle_type") in VEHICLE_TYPES else ""
        cap = f.get("passenger_capacity", "").strip()
        status = f.get("status") if f.get("status") in ("available", "maintenance", "unavailable") else "unavailable"
        errs = []
        if not reg:
            errs.append("Registration number is required.")
        if not vtype:
            errs.append("Choose a vehicle type.")
        if cap and parse_int(cap, 0, 200) is None:
            errs.append("Passenger capacity must be a whole number (0-200).")
        if db.execute("SELECT 1 FROM vehicles WHERE reg_no=? AND id IS NOT ?", (reg, vid)).fetchone():
            errs.append("That registration number already exists.")
        if errs:
            for e in errs:
                flash(e, "error")
        else:
            checked_at = v["availability_checked_at"] if v else None
            checked_by = v["availability_checked_by"] if v else None
            if f.get("availability_checked"):
                checked_at, checked_by = utc_now_iso(), g.user["id"]
            photo = v["photo"] if v else None
            up = request.files.get("photo")
            if up and up.filename:
                from .public import _sniff_image
                data = up.read(5 * 1024 * 1024 + 1)
                ext = _sniff_image(data[:16])
                if ext and len(data) <= 5 * 1024 * 1024:
                    photo = f"veh_{secrets.token_hex(8)}.{ext}"
                    with open(f"{current_app.config['UPLOAD_DIR']}/public/{photo}", "wb") as fh:
                        fh.write(data)
                else:
                    flash("Photo must be JPEG, PNG or WebP under 5 MB; the rest was saved without it.", "error")
            vals = (reg, vtype, clean(f.get("name"), 80), int(cap) if cap else None, clean(f.get("cargo_capacity"), 120),
                    status, checked_at, checked_by, parse_int(f.get("default_driver_id"), 1, 10**9),
                    1 if f.get("show_public") else 0, clean(f.get("description"), 600), photo,
                    1 if f.get("active") else 0)
            if v:
                db.execute("UPDATE vehicles SET reg_no=?,vehicle_type=?,name=?,passenger_capacity=?,cargo_capacity=?,status=?,"
                           "availability_checked_at=?,availability_checked_by=?,default_driver_id=?,show_public=?,description=?,"
                           "photo=?,active=? WHERE id=?", (*vals, vid))
            else:
                db.execute("INSERT INTO vehicles(reg_no,vehicle_type,name,passenger_capacity,cargo_capacity,status,"
                           "availability_checked_at,availability_checked_by,default_driver_id,show_public,description,photo,"
                           "active,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (*vals, utc_now_iso()))
            db.commit()
            flash("Vehicle saved.", "ok")
            return redirect(url_for("admin.vehicles"))
    return render_template("admin/vehicle_form.html", v=v, drivers=drivers, types=VEHICLE_TYPES)


@bp.get("/drivers")
@login_required
def drivers():
    return render_template("admin/drivers.html", rows=get_db().execute("SELECT * FROM drivers ORDER BY status, name").fetchall())


@bp.route("/drivers/new", methods=["GET", "POST"])
@bp.route("/drivers/<int:did>", methods=["GET", "POST"])
@login_required
def driver_form(did=None):
    db = get_db()
    d = db.execute("SELECT * FROM drivers WHERE id=?", (did,)).fetchone() if did else None
    if did and not d:
        abort(404)
    if request.method == "POST":
        f = request.form
        name = clean(f.get("name"), 100)
        phone = clean(f.get("phone"), 24)
        status = f.get("status") if f.get("status") in ("active", "inactive", "on_leave") else "active"
        if len(name) < 2 or (phone and not valid_phone(phone)):
            flash("Enter a name and (optionally) a valid phone number.", "error")
        else:
            vals = (name, phone, clean(f.get("licence_no"), 40), status, clean(f.get("notes"), 500))
            if d:
                db.execute("UPDATE drivers SET name=?,phone=?,licence_no=?,status=?,notes=? WHERE id=?", (*vals, did))
            else:
                db.execute("INSERT INTO drivers(name,phone,licence_no,status,notes,created_at) VALUES(?,?,?,?,?,?)",
                           (*vals, utc_now_iso()))
            db.commit()
            flash("Driver saved.", "ok")
            return redirect(url_for("admin.drivers"))
    return render_template("admin/driver_form.html", d=d)


# =================================================================== enquiries & outbox
@bp.route("/enquiries", methods=["GET", "POST"])
@login_required
def enquiries():
    db = get_db()
    if request.method == "POST":
        eid = parse_int(request.form.get("id"), 1, 10**9)
        if eid:
            db.execute("UPDATE enquiries SET status='handled' WHERE id=?", (eid,))
            db.commit()
        return redirect(url_for("admin.enquiries"))
    return render_template("admin/enquiries.html",
                           rows=db.execute("SELECT * FROM enquiries ORDER BY id DESC LIMIT 200").fetchall())


@bp.get("/outbox")
@login_required
def outbox():
    rows = get_db().execute("SELECT * FROM email_outbox ORDER BY id DESC LIMIT 100").fetchall()
    return render_template("admin/outbox.html", rows=rows, smtp=bool(current_app.config["SMTP_HOST"]))


# =================================================================== reports & export
def _money_sum(rows, col):
    total = Decimal(0)
    for r in rows:
        if r[col]:
            total += Decimal(r[col])
    return total


@bp.get("/reports")
@login_required
def reports():
    db = get_db()
    end = parse_date(request.args.get("to")) or now_fiji().date()
    start = parse_date(request.args.get("from")) or (end - timedelta(days=90))
    rows = db.execute("SELECT * FROM bookings WHERE substr(created_at,1,10) BETWEEN ? AND ?",
                      (start.isoformat(), end.isoformat())).fetchall()
    by_status = Counter(r["status"] for r in rows)
    by_type = Counter(r["booking_type"] for r in rows)
    by_month = Counter(r["created_at"][:7] for r in rows)
    by_dest = Counter(r["dest_address"] for r in rows if not r["anonymised_at"]).most_common(10)
    both = [r for r in rows if r["estimated_price"] and r["final_quote"]]
    est_both, fin_both = _money_sum(both, "estimated_price"), _money_sum(both, "final_quote")
    confirmed = [r for r in rows if r["status"] in CONFIRMED_VALUE and r["final_quote"]]
    completed = [r for r in rows if r["status"] == "Completed" and r["final_quote"]]
    hours = int(get_settings()["default_job_hours"])
    util = defaultdict(lambda: [0, 0.0])
    for r in db.execute("SELECT b.*, v.reg_no FROM bookings b JOIN vehicles v ON v.id=b.vehicle_id "
                        "WHERE b.status IN ('Vehicle/Driver Assigned','In Progress','Completed') AND b.pickup_date BETWEEN ? AND ?",
                        (start.isoformat(), end.isoformat())):
        s, e = _window(r["pickup_dt"], r["return_dt"], hours)
        util[r["reg_no"]][0] += 1
        util[r["reg_no"]][1] += (e - s).total_seconds() / 3600
    return render_template(
        "admin/reports.html", start=start, end=end, total=len(rows), by_status=by_status, by_type=by_type,
        by_month=sorted(by_month.items()), by_dest=by_dest,
        est_all=_money_sum(rows, "estimated_price"),
        quoted=_money_sum([r for r in rows if r["quote_status"] in ("sent", "accepted") and r["final_quote"]], "final_quote"),
        confirmed_value=_money_sum(confirmed, "final_quote"), completed_value=_money_sum(completed, "final_quote"),
        paid=_money_sum([r for r in rows if r["payment_status"] == "paid" and r["final_quote"]], "final_quote"),
        n_both=len(both), est_both=est_both, fin_both=fin_both, util=sorted(util.items()))


def _safe_cell(v):
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + v  # neutralise spreadsheet formula injection
    return v


@bp.get("/export.<fmt>")
@role_required("admin")
def export(fmt):
    if fmt not in ("csv", "xlsx"):
        abort(404)
    db = get_db()
    where, params = _filters(request.args)
    rows = db.execute(f"SELECT b.*, v.reg_no AS veh, d.name AS drv FROM bookings b LEFT JOIN vehicles v ON v.id=b.vehicle_id "
                      f"LEFT JOIN drivers d ON d.id=b.driver_id WHERE {where.replace('status', 'b.status').replace('reference', 'b.reference')} "
                      f"ORDER BY b.created_at DESC", params).fetchall()
    head = ["Reference", "Submitted (UTC)", "Status", "Type", "Customer", "Mobile", "Email", "Pickup", "Destination",
            "Pickup date/time", "Journey", "Distance km", "1st multiplier", "2nd multiplier", "1st result",
            "Estimated price FJD", "Final quote FJD", "Quote status", "Formula version", "Vehicle", "Driver", "Payment status"]
    data = [[r["reference"], r["created_at"], r["status"], r["booking_type"], r["customer_name"], r["mobile"], r["email"],
             r["pickup_address"], r["dest_address"], r["pickup_dt"], r["journey_type"], r["distance_km"],
             r["first_multiplier"], r["second_multiplier"], r["first_result"], r["estimated_price"], r["final_quote"],
             r["quote_status"], r["formula_version"], r["veh"], r["drv"], r["payment_status"]] for r in rows]
    data = [[_safe_cell(c) for c in row] for row in data]
    stamp = now_fiji().strftime("%Y%m%d-%H%M")
    if fmt == "csv":
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(head)
        w.writerows(data)
        return Response("﻿" + buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename=bookings-{stamp}.csv"})
    try:
        from openpyxl import Workbook
    except ImportError:
        flash("Excel export needs the 'openpyxl' package. CSV export works without it.", "error")
        return redirect(url_for("admin.bookings"))
    wb = Workbook()
    ws = wb.active
    ws.title = "Bookings"
    ws.append(head)
    for row in data:
        ws.append(row)
    out = io.BytesIO()
    wb.save(out)
    return Response(out.getvalue(), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f"attachment; filename=bookings-{stamp}.xlsx"})


# =================================================================== retention
@bp.post("/retention/purge")
@role_required("admin")
def retention_purge():
    n = purge_old_data()
    flash(f"Anonymised {n} old booking(s).", "ok")
    return redirect(url_for("admin.business"))


def purge_old_data():
    """Anonymise finished bookings past the retention period; keeps figures needed for reporting."""
    db = get_db()
    days = int(get_settings()["retention_days"])
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).replace(microsecond=0).isoformat()
    rows = db.execute("SELECT id, photos FROM bookings WHERE anonymised_at IS NULL AND "
                      "status IN ('Completed','Cancelled','Rejected') AND updated_at < ?", (cutoff,)).fetchall()
    for r in rows:
        for name in json.loads(r["photos"] or "[]"):
            try:
                os.remove(f"{current_app.config['UPLOAD_DIR']}/private/{name}")
            except OSError:
                pass
        db.execute(
            "UPDATE bookings SET customer_name='REDACTED', mobile='REDACTED', email='redacted@invalid', "
            "pickup_address='REDACTED', dest_address='REDACTED', pickup_lat=NULL, pickup_lng=NULL, pickup_place_id=NULL, "
            "dest_lat=NULL, dest_lng=NULL, dest_place_id=NULL, ret_pickup_address=NULL, ret_pickup_lat=NULL, "
            "ret_pickup_lng=NULL, ret_dest_address=NULL, ret_dest_lat=NULL, ret_dest_lng=NULL, details='{}', "
            "instructions=NULL, photos='[]', route_ref=NULL, client_ip_hash=NULL, anonymised_at=? WHERE id=?",
            (utc_now_iso(), r["id"]))
        db.execute("DELETE FROM booking_notes WHERE booking_id=?", (r["id"],))
        db.execute("UPDATE booking_history SET detail='' WHERE booking_id=?", (r["id"],))
    db.execute("DELETE FROM enquiries WHERE created_at < ?", (cutoff,))
    db.execute("DELETE FROM email_outbox WHERE created_at < ?", (cutoff,))
    db.commit()
    return len(rows)
