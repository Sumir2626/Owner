import os
import secrets
from pathlib import Path


def load_dotenv(path):
    """Tiny .env loader (no dependency). Existing environment variables win."""
    p = Path(path)
    if not p.is_file():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, val = line.split("=", 1)
        val = val.split("  #")[0].strip().strip('"').strip("'")
        os.environ.setdefault(key.strip(), val)


def _bool(name, default):
    return os.environ.get(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


def build_config(root: Path, overrides: dict) -> dict:
    env = os.environ.get
    app_env = env("APP_ENV", "development")
    secret = env("SECRET_KEY")
    if not secret:
        if app_env == "production":
            raise RuntimeError("SECRET_KEY must be set when APP_ENV=production")
        inst = root / "instance"
        inst.mkdir(exist_ok=True)
        f = inst / ".dev_secret"
        if not f.exists():
            f.write_text(secrets.token_hex(32))
        secret = f.read_text().strip()

    def path(name, default):
        p = Path(env(name, default))
        return str(p if p.is_absolute() else root / p)

    cfg = {
        "APP_ENV": app_env,
        "SECRET_KEY": secret,
        "SITE_URL": env("SITE_URL", "http://localhost:5000").rstrip("/"),
        "DATABASE_PATH": path("DATABASE_PATH", "instance/carrier.db"),
        "UPLOAD_DIR": path("UPLOAD_DIR", "instance/uploads"),
        "TRUSTED_PROXY_COUNT": int(env("TRUSTED_PROXY_COUNT", "0") or 0),
        "GOOGLE_MAPS_BROWSER_KEY": env("GOOGLE_MAPS_BROWSER_KEY", ""),
        "GOOGLE_MAPS_SERVER_KEY": env("GOOGLE_MAPS_SERVER_KEY", ""),
        "GOOGLE_MAP_ID": env("GOOGLE_MAP_ID", "DEMO_MAP_ID"),
        "SMTP_HOST": env("SMTP_HOST", ""),
        "SMTP_PORT": int(env("SMTP_PORT", "587") or 587),
        "SMTP_USER": env("SMTP_USER", ""),
        "SMTP_PASSWORD": env("SMTP_PASSWORD", ""),
        "SMTP_STARTTLS": _bool("SMTP_STARTTLS", True),
        "MAIL_FROM": env("MAIL_FROM", "bookings@localhost"),
        "ADMIN_NOTIFY_EMAIL": env("ADMIN_NOTIFY_EMAIL", ""),
        "MAX_UPLOAD_MB": int(env("MAX_UPLOAD_MB", "5") or 5),
        "MAX_CONTENT_LENGTH": 30 * 1024 * 1024,
        "SESSION_COOKIE_HTTPONLY": True,
        "SESSION_COOKIE_SAMESITE": "Lax",
        "SESSION_COOKIE_SECURE": app_env == "production",
        "SESSION_COOKIE_NAME": "carrier_session",
        "PERMANENT_SESSION_LIFETIME": 60 * 60 * 8,
        "TESTING": False,
    }
    cfg.update(overrides)
    return cfg
