import logging
import re
from decimal import Decimal, InvalidOperation
from pathlib import Path

import click
from flask import Flask, g, render_template, request, session
from markupsafe import Markup, escape
from werkzeug.middleware.proxy_fix import ProxyFix

from . import security
from .config import build_config, load_dotenv
from .db import close_db, get_settings, init_db
from .util import to_fiji

STATUSES = [
    "Pending Review", "Quotation Sent", "Confirmed", "Vehicle/Driver Assigned",
    "In Progress", "Completed", "Cancelled", "Rejected",
]


def create_app(overrides=None):
    root = Path(__file__).resolve().parent.parent
    load_dotenv(root / ".env")
    app = Flask(__name__, instance_path=str(root / "instance"))
    app.config.update(build_config(root, overrides or {}))

    for sub in ("public", "private"):
        Path(app.config["UPLOAD_DIR"], sub).mkdir(parents=True, exist_ok=True)
    Path(app.config["DATABASE_PATH"]).parent.mkdir(parents=True, exist_ok=True)

    if app.config["TRUSTED_PROXY_COUNT"]:
        n = app.config["TRUSTED_PROXY_COUNT"]
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=n, x_proto=n, x_host=n)

    logging.basicConfig(level=logging.INFO)
    with app.app_context():
        init_db()

    app.teardown_appcontext(close_db)
    app.before_request(security.load_user)
    app.before_request(security.check_csrf)
    app.after_request(security.add_security_headers)

    from .public import bp as public_bp
    from .admin import bp as admin_bp
    app.register_blueprint(public_bp)
    app.register_blueprint(admin_bp, url_prefix="/admin")

    # ------------------------------------------------------------ templates
    def fjd(v):
        if v in (None, ""):
            return "-"
        try:
            return f"FJ${Decimal(str(v)).quantize(Decimal('0.01')):,.2f}"
        except (InvalidOperation, ValueError):
            return str(v)

    def nl2br(v):
        return Markup("<br>".join(str(escape(line)) for line in (v or "").splitlines()))

    app.jinja_env.filters.update(fjd=fjd, fdt=to_fiji, nl2br=nl2br)
    app.jinja_env.globals["csrf_token"] = security.csrf_token
    app.jinja_env.globals["csp_nonce"] = security.csp_nonce

    @app.context_processor
    def inject():
        s = get_settings()
        wa = re.sub(r"\D", "", s["whatsapp"] or "")
        phone_href = re.sub(r"[^\d+]", "", s["phone"] or "")
        logo = s["logo_path"]
        return {
            "biz": s,
            "wa_url": f"https://wa.me/{wa}" if wa else "",
            "tel_url": f"tel:{phone_href}" if phone_href else "",
            "logo_url": f"/media/public/{logo}" if logo else "",
            "site_url": app.config["SITE_URL"],
            "maps_key_set": bool(app.config["GOOGLE_MAPS_BROWSER_KEY"]),
            "STATUSES": STATUSES,
            "current_user": g.get("user"),
        }

    # ------------------------------------------------------------ errors
    def make_handler(code, title, msg):
        def handler(e):
            detail = getattr(e, "description", "") if code in (400, 413) else ""
            return render_template("error.html", code=code, title=title, msg=msg, detail=detail), code
        return handler

    app.register_error_handler(400, make_handler(400, "Request not accepted", "We could not process that request."))
    app.register_error_handler(401, make_handler(401, "Please sign in", "You need to sign in to do that."))
    app.register_error_handler(403, make_handler(403, "Not permitted", "Your account does not have permission to do that."))
    app.register_error_handler(404, make_handler(404, "Page not found", "That page does not exist."))
    app.register_error_handler(413, make_handler(413, "Upload too large", "The files you uploaded are too large."))
    app.register_error_handler(500, make_handler(500, "Something went wrong", "An unexpected error occurred. Please try again."))

    # ------------------------------------------------------------ CLI
    @app.cli.command("create-admin")
    @click.option("--email", prompt=True)
    @click.option("--name", prompt=True)
    @click.option("--role", type=click.Choice(["admin", "staff"]), default="admin")
    @click.password_option(confirmation_prompt=True)
    def create_admin(email, name, role, password):
        """Create an administrator (or staff) account."""
        from .admin import create_user
        err = create_user(email, name, role, password)
        click.echo(err or f"Created {role} account for {email}")

    @app.cli.command("purge-old")
    def purge_old():
        """Anonymise finished bookings older than the retention period (Business settings)."""
        from .admin import purge_old_data
        click.echo(f"Anonymised {purge_old_data()} booking(s).")

    return app
