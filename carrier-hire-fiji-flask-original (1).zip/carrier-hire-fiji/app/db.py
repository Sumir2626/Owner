import sqlite3

from flask import current_app, g

from .pricing import PricingConfig
from .util import utc_now_iso

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('admin','staff')),
  active INTEGER NOT NULL DEFAULT 1,
  failed_logins INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT,
  last_login TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pricing_versions(
  id INTEGER PRIMARY KEY,
  first_multiplier TEXT NOT NULL,
  second_multiplier TEXT NOT NULL,
  return_rule TEXT NOT NULL DEFAULT 'double',
  return_factor TEXT NOT NULL DEFAULT '2',
  extra_charges TEXT NOT NULL DEFAULT '[]',
  note TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS drivers(
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT,
  licence_no TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  notes TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS vehicles(
  id INTEGER PRIMARY KEY,
  reg_no TEXT UNIQUE NOT NULL,
  vehicle_type TEXT NOT NULL,
  name TEXT,
  passenger_capacity INTEGER,
  cargo_capacity TEXT,
  status TEXT NOT NULL DEFAULT 'unavailable',        -- available | maintenance | unavailable
  availability_checked_at TEXT,                      -- NULL = availability never recorded/checked
  availability_checked_by INTEGER REFERENCES users(id),
  default_driver_id INTEGER REFERENCES drivers(id),
  show_public INTEGER NOT NULL DEFAULT 0,
  description TEXT,
  photo TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bookings(
  id INTEGER PRIMARY KEY,
  reference TEXT UNIQUE NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Pending Review',
  booking_type TEXT NOT NULL CHECK(booking_type IN ('passenger','goods')),
  customer_name TEXT NOT NULL,
  mobile TEXT NOT NULL,
  email TEXT NOT NULL,
  contact_method TEXT NOT NULL,
  pickup_address TEXT NOT NULL, pickup_lat REAL, pickup_lng REAL, pickup_place_id TEXT,
  dest_address TEXT NOT NULL,   dest_lat REAL,   dest_lng REAL,   dest_place_id TEXT,
  journey_type TEXT NOT NULL CHECK(journey_type IN ('one_way','return')),
  return_different INTEGER NOT NULL DEFAULT 0,
  ret_pickup_address TEXT, ret_pickup_lat REAL, ret_pickup_lng REAL,
  ret_dest_address TEXT,   ret_dest_lat REAL,   ret_dest_lng REAL,
  pickup_date TEXT NOT NULL, pickup_time TEXT NOT NULL,
  return_date TEXT, return_time TEXT,
  pickup_dt TEXT NOT NULL,           -- Fiji local 'YYYY-MM-DDTHH:MM'
  return_dt TEXT,
  details TEXT NOT NULL DEFAULT '{}',       -- passenger/goods specific fields (JSON)
  instructions TEXT,
  photos TEXT NOT NULL DEFAULT '[]',
  quote_mode TEXT NOT NULL CHECK(quote_mode IN ('auto','manual')),
  distance_km TEXT,                  -- total driving distance used for the estimate (exact decimal)
  leg_distances TEXT,                -- JSON list of per-leg metres
  route_ref TEXT,                    -- Google Maps directions link(s)
  first_multiplier TEXT, second_multiplier TEXT, first_result TEXT,
  return_rule TEXT, return_factor TEXT,
  formula_version TEXT,
  pricing_breakdown TEXT,            -- full JSON snapshot of the calculation
  estimated_price TEXT,              -- ORIGINAL system estimate, never overwritten
  currency TEXT NOT NULL DEFAULT 'FJD',
  final_quote TEXT,                  -- agreed price, stored separately from the estimate
  final_quote_reason TEXT,
  quote_issued_at TEXT, quote_expires_at TEXT,
  quote_status TEXT NOT NULL DEFAULT 'none',   -- none|draft|sent|accepted|rejected|expired
  vehicle_id INTEGER REFERENCES vehicles(id),
  driver_id INTEGER REFERENCES drivers(id),
  payment_status TEXT NOT NULL DEFAULT 'not_tracked',
  consent_terms INTEGER NOT NULL DEFAULT 0,
  consent_estimate INTEGER NOT NULL DEFAULT 0,
  consent_comms INTEGER NOT NULL DEFAULT 0,
  consent_at TEXT,
  client_ip_hash TEXT,
  anonymised_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_pickup ON bookings(pickup_dt);
CREATE INDEX IF NOT EXISTS idx_bookings_vehicle ON bookings(vehicle_id);

CREATE TABLE IF NOT EXISTS booking_notes(
  id INTEGER PRIMARY KEY,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  user_id INTEGER REFERENCES users(id),
  note TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS booking_history(
  id INTEGER PRIMARY KEY,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  user_id INTEGER REFERENCES users(id),     -- NULL = customer / system
  action TEXT NOT NULL,
  detail TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_history_booking ON booking_history(booking_id);

CREATE TABLE IF NOT EXISTS enquiries(
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT, message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'new',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS email_outbox(
  id INTEGER PRIMARY KEY,
  to_addr TEXT, subject TEXT, body_text TEXT,
  kind TEXT, booking_id INTEGER,
  status TEXT NOT NULL,             -- sent | failed | logged (no SMTP configured) | skipped
  error TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rate_limits(
  key TEXT NOT NULL, window_start INTEGER NOT NULL, count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(key, window_start)
);

CREATE TABLE IF NOT EXISTS drafts(
  id TEXT PRIMARY KEY, payload TEXT NOT NULL, created_at TEXT NOT NULL
);
"""

DEFAULT_SETTINGS = {
    # Business identity - NOTHING here is invented; the administrator supplies real values.
    "business_name": "[Business Name]",
    "tagline": "Passenger transport and goods carrier hire across Fiji",
    "phone": "",
    "whatsapp": "",
    "email": "",
    "address": "",
    "operating_hours": "",
    "service_areas": "",
    "logo_path": "",
    "reference_prefix": "CH",
    "about_text": "",
    "terms_text": "",
    "privacy_text": "",
    "cancellation_text": "",
    "faq_text": "",
    "testimonials_text": "",   # only genuine, permitted testimonials; one per line "Name | quote"
    # Operations
    "admin_notify_email": "",
    "notify_customer_enabled": "1",
    "notify_admin_enabled": "1",
    "quote_valid_days": "7",
    "default_job_hours": "4",
    "retention_days": "730",
    "manual_quote_enabled": "1",
    "manual_quote_message": ("We could not calculate a driving route automatically for this journey. "
                              "Please submit a manual quotation request and our team will price it for you."),
}


def get_db():
    if "db" not in g:
        conn = sqlite3.connect(current_app.config["DATABASE_PATH"], timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=8000")
        g.db = conn
    return g.db


def close_db(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db():
    conn = sqlite3.connect(current_app.config["DATABASE_PATH"], timeout=10)
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript(SCHEMA)
        if conn.execute("SELECT COUNT(*) FROM pricing_versions").fetchone()[0] == 0:
            conn.execute(
                "INSERT INTO pricing_versions(first_multiplier, second_multiplier, return_rule, "
                "return_factor, extra_charges, note, created_at) VALUES('1.1','1.6','double','2','[]',?,?)",
                ("Initial values: (distance x 1.1) x 1.6", utc_now_iso()),
            )
        conn.commit()
    finally:
        conn.close()


def get_settings():
    if "settings" not in g:
        rows = get_db().execute("SELECT key, value FROM settings").fetchall()
        s = dict(DEFAULT_SETTINGS)
        s.update({r["key"]: r["value"] for r in rows})
        g.settings = s
    return g.settings


def set_settings(values: dict):
    db = get_db()
    for k, v in values.items():
        db.execute("INSERT INTO settings(key,value) VALUES(?,?) "
                   "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, v))
    db.commit()
    g.pop("settings", None)


def current_pricing() -> PricingConfig:
    row = get_db().execute("SELECT * FROM pricing_versions ORDER BY id DESC LIMIT 1").fetchone()
    return PricingConfig.from_row(row)


def audit(booking_id, user_id, action, detail=""):
    get_db().execute(
        "INSERT INTO booking_history(booking_id,user_id,action,detail,created_at) VALUES(?,?,?,?,?)",
        (booking_id, user_id, action, detail, utc_now_iso()),
    )
