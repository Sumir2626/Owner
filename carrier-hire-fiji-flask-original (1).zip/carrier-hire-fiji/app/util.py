import re
import secrets
from datetime import date, datetime, time as dtime, timedelta, timezone

try:
    from zoneinfo import ZoneInfo

    FIJI_TZ = ZoneInfo("Pacific/Fiji")
except Exception:  # tzdata missing: Fiji has been on UTC+12 all year since 2022
    FIJI_TZ = timezone(timedelta(hours=12))

REF_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"  # no 0/O/1/I/L


def utc_now_iso():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def now_fiji():
    """Current Fiji wall-clock time as a naive datetime."""
    return datetime.now(FIJI_TZ).replace(tzinfo=None, microsecond=0)


def to_fiji(iso):
    if not iso:
        return ""
    try:
        d = datetime.fromisoformat(iso)
    except ValueError:
        return str(iso)
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d.astimezone(FIJI_TZ).strftime("%d %b %Y, %H:%M")


def new_reference(prefix="CH"):
    prefix = re.sub(r"[^A-Z0-9]", "", (prefix or "CH").upper())[:6] or "CH"
    rnd = "".join(secrets.choice(REF_ALPHABET) for _ in range(5))
    return f"{prefix}-{now_fiji():%y%m%d}-{rnd}"


_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def clean(value, maxlen=200):
    """Trim, strip control characters, cap length. Always returns str."""
    if value is None:
        return ""
    s = _CTRL.sub("", str(value)).strip()
    return s[:maxlen]


_EMAIL = re.compile(r"^[^@\s<>]+@[^@\s<>]+\.[^@\s<>]{2,}$")


def valid_email(s):
    return bool(s) and len(s) <= 254 and bool(_EMAIL.match(s))


def valid_phone(s):
    if not s or not re.fullmatch(r"[0-9+()\-. ]{7,24}", s):
        return False
    return 7 <= len(re.sub(r"\D", "", s)) <= 15


def parse_date(s):
    try:
        return date.fromisoformat((s or "").strip())
    except ValueError:
        return None


def parse_time(s):
    try:
        h, m = (s or "").strip().split(":")[:2]
        return dtime(int(h), int(m))
    except (ValueError, TypeError):
        return None


def parse_int(s, lo, hi):
    try:
        n = int(str(s).strip())
    except (ValueError, TypeError):
        return None
    return n if lo <= n <= hi else None
