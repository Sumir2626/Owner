"""Google Routes API client (server side only) and Fiji validation.

The server key never reaches the browser. Routes are requested for DRIVE mode
with ferries avoided, so a result is always a genuine road route; if Google
cannot produce one (islands, ferry-only links, unmapped roads) we raise
RouteUnavailable and the website offers a manual quotation instead of a price.
"""
import json
import math
import urllib.error
import urllib.request
from dataclasses import dataclass

ROUTES_URL = "https://routes.googleapis.com/directions/v2:computeRoutes"
FIELD_MASK = "routes.distanceMeters,routes.duration,routes.polyline.encodedPolyline"

# Coarse bounding region for Fiji. It crosses the 180th meridian (Taveuni, Rabi,
# Lau group are on the western-hemisphere side), so longitude is two ranges.
FIJI_LAT_MIN, FIJI_LAT_MAX = -21.2, -12.2
FIJI_LNG_EAST_MIN = 176.8  # eastern hemisphere side (Viti Levu, Vanua Levu, Rotuma...)
FIJI_LNG_WEST_MAX = -178.0  # western hemisphere side (Taveuni, Lau group)


class RouteUnavailable(Exception):
    """Google answered, but there is no drivable route between the points."""


class RouteError(Exception):
    """Configuration, network, quota, or API failure."""


@dataclass
class Route:
    distance_m: int
    duration_s: int
    polyline: str


def in_fiji(lat: float, lng: float) -> bool:
    if not (FIJI_LAT_MIN <= lat <= FIJI_LAT_MAX):
        return False
    return lng >= FIJI_LNG_EAST_MIN or lng <= FIJI_LNG_WEST_MAX


def haversine_km(a, b) -> float:
    r = 6371.0088
    p1, p2 = math.radians(a["lat"]), math.radians(b["lat"])
    dphi = p2 - p1
    dl = math.radians(b["lng"] - a["lng"])
    h = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


def maps_directions_url(o, d):
    """Link that opens the route in Google Maps (for admins and customers)."""
    from urllib.parse import quote_plus

    def loc(p):
        if p.get("lat") is not None and p.get("lng") is not None:
            return f"{p['lat']},{p['lng']}"
        return quote_plus(p.get("address", ""))

    return ("https://www.google.com/maps/dir/?api=1&travelmode=driving"
            f"&origin={loc(o)}&destination={loc(d)}")


def compute_route(origin: dict, dest: dict, api_key: str, timeout: int = 10) -> Route:
    if not api_key:
        raise RouteError("GOOGLE_MAPS_SERVER_KEY is not configured")
    body = {
        "origin": {"location": {"latLng": {"latitude": origin["lat"], "longitude": origin["lng"]}}},
        "destination": {"location": {"latLng": {"latitude": dest["lat"], "longitude": dest["lng"]}}},
        "travelMode": "DRIVE",
        "routingPreference": "TRAFFIC_UNAWARE",
        "routeModifiers": {"avoidFerries": True},
        "units": "METRIC",
        "languageCode": "en",
        "regionCode": "FJ",
    }
    req = urllib.request.Request(
        ROUTES_URL,
        data=json.dumps(body).encode(),
        method="POST",
        headers={
            "Content-Type": "application/json",
            "X-Goog-Api-Key": api_key,
            "X-Goog-FieldMask": FIELD_MASK,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.load(resp)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise RouteUnavailable("no route")
        detail = e.read()[:300].decode("utf-8", "replace")
        raise RouteError(f"Routes API HTTP {e.code}: {detail}")
    except (urllib.error.URLError, TimeoutError, ValueError, OSError) as e:
        raise RouteError(f"Routes API request failed: {e}")

    routes = data.get("routes") or []
    if not routes or "distanceMeters" not in routes[0]:
        raise RouteUnavailable("no route")
    r = routes[0]
    try:
        duration = int(str(r.get("duration", "0s")).rstrip("s") or 0)
    except ValueError:
        duration = 0
    return Route(
        distance_m=int(r["distanceMeters"]),
        duration_s=duration,
        polyline=(r.get("polyline") or {}).get("encodedPolyline", ""),
    )
