"""Pricing engine - the single source of truth for quotations.

Mandatory business rule (implemented exactly):

    First Amount          = Driving Distance (km) x first_multiplier   (initially 1.1)
    Final Estimated Price = First Amount        x second_multiplier    (initially 1.6)

The two multipliers are MULTIPLIED in sequence, never added. All maths uses
Decimal. The full distance (exact metres / 1000) is used throughout; only the
final money amount is rounded, to 2 decimals, half-up.

The same function runs when a quote is requested and again when a booking is
submitted, so the website can never be talked into a different price.
"""
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import json

CURRENCY = "FJD"
CENT = Decimal("0.01")
MAX_MULTIPLIER = Decimal("10")
RETURN_RULES = {
    "double": "Return trip = 2 x one-way estimate (default)",
    "factor": "Return trip = one-way estimate x a configured factor",
}


@dataclass(frozen=True)
class PricingConfig:
    first: Decimal = Decimal("1.1")
    second: Decimal = Decimal("1.6")
    return_rule: str = "double"
    return_factor: Decimal = Decimal("2")
    extras: tuple = ()  # ((label, Decimal amount), ...) explicit, disclosed charges
    version: str = "PV0"

    def to_dict(self):
        return {
            "first": str(self.first),
            "second": str(self.second),
            "return_rule": self.return_rule,
            "return_factor": str(self.return_factor),
            "extras": [[label, str(amt)] for label, amt in self.extras],
            "version": self.version,
        }

    @classmethod
    def from_dict(cls, d):
        return cls(
            first=Decimal(d["first"]),
            second=Decimal(d["second"]),
            return_rule=d.get("return_rule", "double"),
            return_factor=Decimal(d.get("return_factor", "2")),
            extras=tuple((label, Decimal(a)) for label, a in d.get("extras", [])),
            version=d.get("version", "PV0"),
        )

    @classmethod
    def from_row(cls, row):
        extras = json.loads(row["extra_charges"] or "[]")
        return cls(
            first=Decimal(row["first_multiplier"]),
            second=Decimal(row["second_multiplier"]),
            return_rule=row["return_rule"],
            return_factor=Decimal(row["return_factor"]),
            extras=tuple((e["label"], Decimal(str(e["amount"]))) for e in extras),
            version=f"PV{row['id']}",
        )

    @property
    def formula_text(self):
        return f"(distance_km × {plain(self.first)}) × {plain(self.second)}"


def plain(d: Decimal) -> str:
    """Decimal -> plain string without exponent or trailing zeros ('110', '27.5')."""
    s = format(d, "f")
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s or "0"


def money(d: Decimal) -> Decimal:
    return d.quantize(CENT, rounding=ROUND_HALF_UP)


def fmt_money(d: Decimal) -> str:
    return f"FJ${money(d):,.2f}"


def parse_multiplier(text, label="Multiplier"):
    """Validate admin input: positive, <= 10, at most 4 decimal places."""
    try:
        d = Decimal(str(text).strip())
    except (InvalidOperation, ValueError):
        raise ValueError(f"{label} must be a number.")
    if not d.is_finite() or d <= 0 or d > MAX_MULTIPLIER:
        raise ValueError(f"{label} must be greater than 0 and at most {MAX_MULTIPLIER}.")
    if d != d.quantize(Decimal("0.0001")):
        raise ValueError(f"{label} may have at most 4 decimal places.")
    return d.normalize() if d != d.to_integral() else d.quantize(Decimal("1"))


def leg_calc(distance_m: int, cfg: PricingConfig) -> dict:
    km = Decimal(int(distance_m)) / Decimal(1000)  # exact: metres give 3 dp
    first = km * cfg.first
    final = first * cfg.second  # NOT unrounded-then-added: sequential multiply
    return {
        "distance_m": int(distance_m),
        "distance_km": plain(km),
        "first_multiplier": plain(cfg.first),
        "first_result": plain(first),
        "second_multiplier": plain(cfg.second),
        "final_unrounded": plain(final),
        "price": f"{money(final):.2f}",
        "_final": final,
    }


def build_quote(leg_distances_m, journey_type, cfg: PricingConfig, return_different=False) -> dict:
    """Return a complete, display-ready quotation for one or two route legs.

    leg_distances_m: [outbound] or [outbound, return-leg] (return leg only when
    the return route differs from the outbound route).
    """
    legs = [leg_calc(m, cfg) for m in leg_distances_m]
    lines = []
    for i, leg in enumerate(legs):
        tag = "" if len(legs) == 1 else (f"Outbound: " if i == 0 else "Return leg: ")
        lines.append({
            "label": f"{tag}Step 1 - distance × {leg['first_multiplier']}",
            "text": f"{leg['distance_km']} km × {leg['first_multiplier']} = {leg['first_result']}",
        })
        lines.append({
            "label": f"{tag}Step 2 - first result × {leg['second_multiplier']}",
            "text": f"{leg['first_result']} × {leg['second_multiplier']} = {fmt_money(leg['_final'])}",
        })

    one_way = legs[0]["_final"]
    note = ""
    if journey_type == "return" and return_different and len(legs) == 2:
        subtotal = legs[0]["_final"] + legs[1]["_final"]
        lines.append({"label": "Return trip - both legs",
                      "text": f"{fmt_money(legs[0]['_final'])} + {fmt_money(legs[1]['_final'])} = {fmt_money(subtotal)}"})
        note = ("Because the return journey uses a different route, each leg was calculated "
                "separately and added together. Amounts are rounded only at the end.")
    elif journey_type == "return":
        if cfg.return_rule == "factor":
            subtotal = one_way * cfg.return_factor
            lines.append({"label": "Return trip",
                          "text": f"{fmt_money(one_way)} × {plain(cfg.return_factor)} = {fmt_money(subtotal)}"})
        else:
            subtotal = one_way * 2
            lines.append({"label": "Return trip - both legs",
                          "text": f"{fmt_money(one_way)} × 2 = {fmt_money(subtotal)}"})
        note = ("The return-trip estimate assumes the return journey covers the same distance "
                "and that both legs are included in the quotation.")
    else:
        subtotal = one_way

    total = money(subtotal)
    extras = []
    for label, amt in cfg.extras:
        extras.append({"label": label, "amount": f"{money(amt):.2f}"})
        total += money(amt)
        lines.append({"label": f"Additional charge: {label}", "text": f"+ {fmt_money(amt)}"})
    if extras:
        lines.append({"label": "Total", "text": fmt_money(total)})

    return {
        "currency": CURRENCY,
        "journey_type": journey_type,
        "return_different": bool(return_different and len(legs) == 2),
        "formula": cfg.formula_text,
        "formula_version": cfg.version,
        "first_multiplier": plain(cfg.first),
        "second_multiplier": plain(cfg.second),
        "return_rule": cfg.return_rule,
        "return_factor": plain(cfg.return_factor),
        "legs": [{k: v for k, v in leg.items() if k != "_final"} for leg in legs],
        "total_distance_km": plain(sum((Decimal(l["distance_m"]) for l in legs), Decimal(0)) / 1000),
        "one_way_price": f"{money(one_way):.2f}",
        "route_total": f"{money(subtotal):.2f}",
        "extras": extras,
        "total": f"{total:.2f}",
        "total_display": fmt_money(total),
        "lines": lines,
        "note": note,
    }
