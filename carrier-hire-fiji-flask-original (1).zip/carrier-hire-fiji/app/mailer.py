"""Email notifications.

If SMTP_HOST is set, mail is sent through SMTP. If not (development), every
message is still written to the email_outbox table with status 'logged' so
nothing is lost and the admin Outbox page shows what would have been sent.
A mail failure NEVER breaks a booking: it is recorded as 'failed'.

Estimated vs final: every email states clearly whether a figure is an
ESTIMATE (system formula, not a price) or the FINAL APPROVED QUOTATION.
"""
import smtplib
from email.message import EmailMessage
from email.utils import formatdate

from flask import current_app

from .db import get_db, get_settings
from .util import to_fiji, utc_now_iso
from .pricing import fmt_money

JOURNEY = {"one_way": "One-way", "return": "Return"}
TYPE = {"passenger": "Passenger transport", "goods": "Goods transport"}


def _fmt_money(v):
    return fmt_money(__import__("decimal").Decimal(v)) if v not in (None, "") else "-"


def send(to, subject, text, kind, booking_id=None):
    db = get_db()
    cfg = current_app.config
    status, err = "logged", None
    if not to:
        status, err = "skipped", "no recipient configured"
    elif cfg["SMTP_HOST"]:
        try:
            msg = EmailMessage()
            msg["Subject"] = subject
            msg["From"] = cfg["MAIL_FROM"]
            msg["To"] = to
            msg["Date"] = formatdate(localtime=False)
            msg.set_content(text)
            with smtplib.SMTP(cfg["SMTP_HOST"], cfg["SMTP_PORT"], timeout=15) as smtp:
                if cfg["SMTP_STARTTLS"]:
                    smtp.starttls()
                if cfg["SMTP_USER"]:
                    smtp.login(cfg["SMTP_USER"], cfg["SMTP_PASSWORD"])
                smtp.send_message(msg)
            status = "sent"
        except Exception as exc:  # noqa: BLE001 - never let email break a booking
            status, err = "failed", str(exc)[:300]
            current_app.logger.warning("Email failed (%s): %s", kind, err)
    db.execute(
        "INSERT INTO email_outbox(to_addr,subject,body_text,kind,booking_id,status,error,created_at) "
        "VALUES(?,?,?,?,?,?,?,?)",
        (to, subject, text, kind, booking_id, status, err, utc_now_iso()),
    )
    db.commit()
    return status


def quote_block(b):
    """Plain-text quotation section that cannot be mistaken for a final price."""
    lines = []
    if b["quote_mode"] == "manual" and not b["final_quote"]:
        lines.append("QUOTATION: Manual quotation requested. Our team will prepare a price for you.")
    elif b["estimated_price"]:
        lines.append(f"ESTIMATED QUOTATION (approximate, NOT a final price): {_fmt_money(b['estimated_price'])}")
        lines.append(f"  Based on {b['distance_km']} km driving distance, formula "
                     f"({b['first_multiplier']} then {b['second_multiplier']}), version {b['formula_version']}.")
    if b["final_quote"]:
        lines.append(f"FINAL APPROVED QUOTATION: {_fmt_money(b['final_quote'])}")
        if b["final_quote_reason"]:
            lines.append(f"  Basis / reason for any change from the estimate: {b['final_quote_reason']}")
        if b["quote_expires_at"]:
            lines.append(f"  Valid until: {b['quote_expires_at']}")
    return "\n".join(lines)


def summary(b):
    when = f"{b['pickup_date']} {b['pickup_time']}"
    rows = [
        ("Booking reference", b["reference"]),
        ("Customer", b["customer_name"]),
        ("Service", TYPE.get(b["booking_type"], b["booking_type"])),
        ("Pickup", b["pickup_address"]),
        ("Destination", b["dest_address"]),
        ("Pickup date/time", when),
        ("Journey type", JOURNEY.get(b["journey_type"], b["journey_type"])),
    ]
    if b["journey_type"] == "return" and b["return_date"]:
        rows.append(("Return date/time", f"{b['return_date']} {b['return_time']}"))
    if b["distance_km"]:
        rows.append(("Estimated driving distance", f"{b['distance_km']} km"))
    rows.append(("Status", b["status"]))
    width = max(len(k) for k, _ in rows)
    return "\n".join(f"{k.ljust(width)} : {v}" for k, v in rows)


def _compose(b, headline, intro, extra=""):
    s = get_settings()
    parts = [headline, "", intro, "", summary(b), "", quote_block(b)]
    if extra:
        parts += ["", extra]
    contact = [x for x in (s["phone"], s["email"]) if x]
    parts += ["", "Check your booking status any time at "
              f"{current_app.config['SITE_URL']}/booking-status (reference + your email address)."]
    if contact:
        parts.append("Questions? Contact us: " + " | ".join(contact))
    parts += ["", f"- {s['business_name']}"]
    return "\n".join(p for p in parts if p is not None)


CUSTOMER = {
    "received": ("Booking request received",
                 "Thank you. We have received your request and it is awaiting review by our team. "
                 "THIS IS NOT YET A CONFIRMED BOOKING, and any price shown is only an estimate."),
    "quote_sent": ("Your quotation",
                   "Our team has reviewed your request and prepared the quotation below. "
                   "Please check your booking status page to accept or decline it."),
    "confirmed": ("Booking confirmed",
                  "Good news - your booking has been confirmed by our team."),
    "rescheduled": ("Booking rescheduled",
                    "Your booking has been rescheduled. The updated date and time are shown below."),
    "cancelled": ("Booking cancelled", "Your booking has been cancelled."),
    "rejected": ("Booking request could not be accepted",
                 "Unfortunately we are unable to accept this request."),
    "completed": ("Booking completed", "Your booking is marked as completed. Thank you for choosing us."),
}

ADMIN = {
    "new_booking": "New booking request",
    "new_manual_quote": "New MANUAL quotation request",
    "quote_accepted": "Customer ACCEPTED quotation",
    "quote_rejected": "Customer DECLINED quotation",
    "cancel_request": "Customer requests CANCELLATION",
    "reschedule_request": "Customer requests RESCHEDULING",
}


def customer(kind, b, extra=""):
    s = get_settings()
    if s["notify_customer_enabled"] != "1":
        return None
    title, intro = CUSTOMER[kind]
    subject = f"{title} - {b['reference']}"
    return send(b["email"], subject, _compose(b, f"{title.upper()} ({b['reference']})", intro, extra),
                f"customer_{kind}", b["id"])


def admin(kind, b, extra=""):
    s = get_settings()
    if s["notify_admin_enabled"] != "1":
        return None
    to = s["admin_notify_email"] or current_app.config["ADMIN_NOTIFY_EMAIL"]
    title = ADMIN[kind]
    link = f"{current_app.config['SITE_URL']}/admin/bookings/{b['id']}"
    intro = f"{title}. Open in the dashboard: {link}"
    body = _compose(b, f"[ADMIN] {title} ({b['reference']})", intro,
                    extra + ("\n" if extra else "") + f"Customer contact: {b['mobile']} / {b['email']} "
                    f"(prefers {b['contact_method']})")
    return send(to, f"[{title}] {b['reference']} - {b['customer_name']}", body, f"admin_{kind}", b["id"])


def admin_enquiry(name, email, phone, message):
    s = get_settings()
    if s["notify_admin_enabled"] != "1":
        return None
    to = s["admin_notify_email"] or current_app.config["ADMIN_NOTIFY_EMAIL"]
    body = f"New website enquiry\n\nName : {name}\nEmail: {email}\nPhone: {phone or '-'}\n\n{message}\n"
    return send(to, f"[New enquiry] {name}", body, "admin_enquiry")
