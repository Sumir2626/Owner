from decimal import Decimal

import pytest

from app import pricing
from app.maps import in_fiji
from app.pricing import PricingConfig, build_quote, parse_multiplier

CFG = PricingConfig()  # initial business values 1.1 and 1.6


@pytest.mark.parametrize("km,first,price", [
    (10, "11", "17.60"), (25, "27.5", "44.00"), (50, "55", "88.00"),
    (100, "110", "176.00"), (200, "220", "352.00"), (300, "330", "528.00"),
])
def test_spec_examples(km, first, price):
    q = build_quote([km * 1000], "one_way", CFG)
    leg = q["legs"][0]
    assert leg["first_result"] == first and q["total"] == price
    assert q["total_display"] == f"FJ${price}" or q["total_display"].replace(",", "") == f"FJ${price}"


def test_100km_steps_are_shown_separately():
    q = build_quote([100000], "one_way", CFG)
    texts = [l["text"] for l in q["lines"]]
    assert texts[0] == "100 km × 1.1 = 110"
    assert texts[1] == "110 × 1.6 = FJ$176.00"


def test_multipliers_are_multiplied_not_added():
    q = build_quote([100000], "one_way", CFG)
    assert q["total"] != "270.00"  # (100*1.1)+(100*1.6) would be wrong
    assert q["total"] == "176.00"


def test_full_distance_used_and_only_money_rounded():
    # 12.345 km x 1.1 = 13.5795 ; x 1.6 = 21.7272 -> 21.73
    q = build_quote([12345], "one_way", CFG)
    assert q["legs"][0]["first_result"] == "13.5795"
    assert q["legs"][0]["final_unrounded"] == "21.72720"[:-1] or q["legs"][0]["final_unrounded"] == "21.7272"
    assert q["total"] == "21.73"


def test_half_up_rounding_no_float_error():
    cfg = PricingConfig(first=Decimal("1"), second=Decimal("1.005"))
    assert build_quote([1000], "one_way", cfg)["total"] == "1.01"


def test_return_trip_doubles_one_way():
    q = build_quote([100000], "return", CFG)
    assert q["one_way_price"] == "176.00" and q["total"] == "352.00"
    assert "same distance" in q["note"] and "both legs" in q["note"]


def test_return_with_different_route_prices_legs_separately():
    q = build_quote([100000, 60000], "return", CFG, return_different=True)
    assert [l["price"] for l in q["legs"]] == ["176.00", "105.60"]
    assert q["total"] == "281.60"


def test_return_factor_rule():
    cfg = PricingConfig(return_rule="factor", return_factor=Decimal("1.8"))
    assert build_quote([100000], "return", cfg)["total"] == "316.80"


def test_additional_charges_are_explicit_lines():
    cfg = PricingConfig(extras=(("Airport fee", Decimal("10")),))
    q = build_quote([100000], "one_way", cfg)
    assert q["total"] == "186.00" and q["extras"] == [{"label": "Airport fee", "amount": "10.00"}]
    assert any("Airport fee" in l["label"] for l in q["lines"])


def test_changing_config_does_not_change_old_quote_dict():
    old = build_quote([100000], "one_way", CFG)
    new = build_quote([100000], "one_way", PricingConfig(first=Decimal("1.2"), second=Decimal("1.5")))
    assert old["total"] == "176.00" and new["total"] == "180.00"
    assert old["first_multiplier"] == "1.1" and new["first_multiplier"] == "1.2"


@pytest.mark.parametrize("bad", ["", "abc", "0", "-1", "11", "1.12345", "nan", "inf"])
def test_multiplier_validation(bad):
    with pytest.raises(ValueError):
        parse_multiplier(bad)


def test_fiji_bounds_including_antimeridian():
    assert in_fiji(-18.14, 178.44)      # Suva
    assert in_fiji(-16.85, -179.97)     # Taveuni, western-hemisphere side
    assert in_fiji(-12.5, 177.07)       # Rotuma
    assert not in_fiji(-33.87, 151.21)  # Sydney
    assert not in_fiji(-21.14, -175.2)  # Tonga
    assert not in_fiji(-9.0, 160.0)     # Solomon Islands
