import json

import pytest

from conftest import csrf, db_rows, future, login, make_booking, submit_booking, api_quote


def bid(app):
    return db_rows(app, "SELECT id FROM bookings ORDER BY id")[-1]["id"]


@pytest.fixture()
def booked(app, client, routes):
    make_booking(app, client, routes, km=100)
    admin = app.test_client()
    tok = login(app, admin)
    return admin, tok, bid(app)


def post(c, url, tok, **data):
    return c.post(url, data={"csrf_token": tok, **data})


# ------------------------------------------------------------ access control
def test_admin_pages_require_login(app, client):
    for url in ("/admin/", "/admin/bookings", "/admin/bookings/1", "/admin/pricing", "/admin/vehicles",
                "/admin/reports", "/admin/export.csv", "/admin/users", "/admin/outbox"):
        r = client.get(url)
        assert r.status_code == 302 and "/admin/login" in r.headers["Location"], url


def test_anonymous_cannot_change_prices(app, client):
    t = csrf(client)
    r = client.post("/admin/pricing", data={"csrf_token": t, "first": "0.1", "second": "0.1"})
    assert r.status_code == 401
    assert client.post("/admin/pricing", data={"first": "0.1"}).status_code == 400  # no CSRF either
    assert db_rows(app, "SELECT COUNT(*) n FROM pricing_versions")[0]["n"] == 1


def test_staff_cannot_reach_admin_only_areas(app):
    c = app.test_client()
    tok = login(app, c, "staff@example.com", role="staff")
    for url in ("/admin/pricing", "/admin/business", "/admin/users", "/admin/export.csv"):
        assert c.get(url).status_code == 403, url
    assert post(c, "/admin/pricing", tok, first="0.5", second="0.5", note="x", password="x").status_code == 403
    assert c.get("/admin/bookings").status_code == 200


def test_login_lockout_and_generic_error(app, client):
    from app.admin import create_user
    with app.app_context():
        create_user("a@example.com", "Alice", "admin", "correct-horse-battery")
    for _ in range(5):
        r = client.post("/admin/login", data={"email": "a@example.com", "password": "wrong", "csrf_token": csrf(client)})
        assert "Incorrect email or password" in r.get_data(as_text=True)
    r = client.post("/admin/login", data={"email": "a@example.com", "password": "correct-horse-battery", "csrf_token": csrf(client)})
    assert r.status_code == 200 and "locked" in r.get_data(as_text=True)


def test_open_redirect_blocked_on_login(app, client):
    from app.admin import create_user
    with app.app_context():
        create_user("a@example.com", "Alice", "admin", "correct-horse-battery")
    r = client.post("/admin/login?next=//evil.example", data={"email": "a@example.com", "password": "correct-horse-battery", "csrf_token": csrf(client)})
    assert r.status_code == 302 and "evil" not in r.headers["Location"]


def test_weak_password_rejected(app):
    from app.admin import create_user
    with app.app_context():
        assert "12 characters" in create_user("a@example.com", "Alice", "admin", "short")


# ------------------------------------------------------------ booking management
def test_booking_visible_in_dashboard_and_detail(app, booked):
    admin, tok, b = booked
    assert "Pending review" in admin.get("/admin/").get_data(as_text=True)
    lst = admin.get("/admin/bookings?q=Suva").get_data(as_text=True)
    assert "CH-" in lst and "FJ$176.00" in lst
    assert "CH-" not in admin.get("/admin/bookings?q=zzzz").get_data(as_text=True).split("<tbody>")[1]
    assert "CH-" in admin.get("/admin/bookings?type=passenger&status=Pending+Review").get_data(as_text=True)
    page = admin.get(f"/admin/bookings/{b}").get_data(as_text=True)
    assert "100 km × 1.1 = 110" in page and "110 × 1.6 = FJ$176.00" in page
    assert "google.com/maps/dir" in page and "Open route in Google Maps" in page


def test_final_quote_kept_separate_from_estimate(app, booked):
    admin, tok, b = booked
    # a different price needs a reason
    post(admin, f"/admin/bookings/{b}/quote", tok, action="save", final_quote="200")
    assert db_rows(app, "SELECT final_quote FROM bookings")[0]["final_quote"] is None
    post(admin, f"/admin/bookings/{b}/quote", tok, action="save", final_quote="200", reason="Extra waiting time")
    row = db_rows(app, "SELECT * FROM bookings")[0]
    assert (row["estimated_price"], row["final_quote"], row["quote_status"]) == ("176.00", "200.00", "draft")
    assert row["final_quote_reason"] == "Extra waiting time"
    # invalid money
    post(admin, f"/admin/bookings/{b}/quote", tok, action="save", final_quote="abc", reason="x")
    assert db_rows(app, "SELECT final_quote FROM bookings")[0]["final_quote"] == "200.00"
    hist = [h["action"] for h in db_rows(app, "SELECT action FROM booking_history")]
    assert "final_quote_set" in hist


def test_cannot_confirm_without_final_quote_and_no_auto_confirm(app, booked):
    admin, tok, b = booked
    r = post(admin, f"/admin/bookings/{b}/status", tok, status="Confirmed")
    assert db_rows(app, "SELECT status FROM bookings")[0]["status"] == "Pending Review"
    post(admin, f"/admin/bookings/{b}/status", tok, status="In Progress")  # illegal jump
    assert db_rows(app, "SELECT status FROM bookings")[0]["status"] == "Pending Review"
    post(admin, f"/admin/bookings/{b}/status", tok, status="Cancelled")  # reason required
    assert db_rows(app, "SELECT status FROM bookings")[0]["status"] == "Pending Review"


def test_full_lifecycle_and_emails(app, booked):
    admin, tok, b = booked
    u = f"/admin/bookings/{b}"
    post(admin, u + "/quote", tok, action="send", final_quote="190", reason="Includes a toll", expires=future(10))
    row = db_rows(app, "SELECT * FROM bookings")[0]
    assert row["status"] == "Quotation Sent" and row["quote_status"] == "sent"
    # customer accepts via status page
    cust = app.test_client()
    cust.post("/booking-status", data={"reference": row["reference"], "email": "cust@example.com", "csrf_token": csrf(cust)})
    cust.post(f"/booking-status/{row['reference']}/accept-quote", data={"csrf_token": csrf(cust)})
    assert db_rows(app, "SELECT quote_status FROM bookings")[0]["quote_status"] == "accepted"
    post(admin, u + "/status", tok, status="Confirmed")
    assert db_rows(app, "SELECT status FROM bookings")[0]["status"] == "Confirmed"
    post(admin, u + "/reschedule", tok, pickup_date=future(8), pickup_time="10:30", reason="Customer request")
    assert db_rows(app, "SELECT pickup_time FROM bookings")[0]["pickup_time"] == "10:30"
    post(admin, u + "/status", tok, status="Cancelled", reason="Customer cancelled", share_reason="on")
    assert db_rows(app, "SELECT status FROM bookings")[0]["status"] == "Cancelled"
    kinds = [m["kind"] for m in db_rows(app, "SELECT kind FROM email_outbox ORDER BY id")]
    assert kinds == ["customer_received", "admin_new_booking", "customer_quote_sent", "admin_quote_accepted",
                     "customer_confirmed", "customer_rescheduled", "customer_cancelled"]
    mails = {m["kind"]: m["body_text"] for m in db_rows(app, "SELECT kind, body_text FROM email_outbox")}
    assert "FINAL APPROVED QUOTATION: FJ$190.00" in mails["customer_quote_sent"]
    assert "ESTIMATED QUOTATION" in mails["customer_quote_sent"]  # estimate still labelled as estimate
    assert "Customer ACCEPTED" in mails["admin_quote_accepted"]
    assert db_rows(app, "SELECT COUNT(*) n FROM booking_history")[0]["n"] >= 7  # change history kept
    assert db_rows(app, "SELECT status FROM bookings")[0]["status"] == "Cancelled"
    # closed bookings cannot be changed
    post(admin, u + "/status", tok, status="Confirmed")
    assert db_rows(app, "SELECT status FROM bookings")[0]["status"] == "Cancelled"


def test_use_estimate_as_final(app, booked):
    admin, tok, b = booked
    post(admin, f"/admin/bookings/{b}/quote", tok, action="use_estimate")
    row = db_rows(app, "SELECT * FROM bookings")[0]
    assert row["final_quote"] == "176.00" and row["estimated_price"] == "176.00"


def test_internal_notes(app, booked):
    admin, tok, b = booked
    post(admin, f"/admin/bookings/{b}/note", tok, note="Customer prefers a morning pickup")
    assert "morning pickup" in admin.get(f"/admin/bookings/{b}").get_data(as_text=True)


def test_stored_xss_is_escaped(app, client, routes):
    make_booking(app, client, routes, customer_name="<script>alert(1)</script>")
    admin = app.test_client()
    login(app, admin)
    b = bid(app)
    for url in ("/admin/bookings", f"/admin/bookings/{b}", "/admin/"):
        html = admin.get(url).get_data(as_text=True)
        assert "<script>alert(1)" not in html, url


# ------------------------------------------------------------ vehicles and drivers
def add_vehicle(admin, tok, reg, checked=True, status="available", seats="14"):
    data = {"csrf_token": tok, "reg_no": reg, "vehicle_type": "Minibus", "passenger_capacity": seats, "status": status}
    if checked:
        data["availability_checked"] = "on"
    data["active"] = "on"
    return admin.post("/admin/vehicles/new", data=data)


def test_vehicle_not_assignable_until_availability_checked(app, booked):
    admin, tok, b = booked
    add_vehicle(admin, tok, "FJ 001", checked=False)
    assert "Not recorded" in admin.get("/admin/vehicles").get_data(as_text=True) or \
        "not checked" in admin.get("/admin/vehicles").get_data(as_text=True)
    post(admin, f"/admin/bookings/{b}/quote", tok, action="use_estimate")
    post(admin, f"/admin/bookings/{b}/status", tok, status="Confirmed")
    v = db_rows(app, "SELECT id FROM vehicles")[0]["id"]
    post(admin, f"/admin/bookings/{b}/assign", tok, vehicle_id=v)
    assert db_rows(app, "SELECT vehicle_id, status FROM bookings")[0] == {"vehicle_id": None, "status": "Confirmed"}
    # record + check availability, now it works
    admin.post(f"/admin/vehicles/{v}", data={"csrf_token": tok, "reg_no": "FJ 001", "vehicle_type": "Minibus",
               "passenger_capacity": "14", "status": "available", "availability_checked": "on", "active": "on"})
    post(admin, f"/admin/bookings/{b}/assign", tok, vehicle_id=v)
    assert db_rows(app, "SELECT vehicle_id, status FROM bookings")[0] == {"vehicle_id": v, "status": "Vehicle/Driver Assigned"}


def two_bookings(app, client, routes, admin, tok):
    ids = []
    for _ in range(2):
        token = api_quote(client).json["token"]
        assert submit_booking(app, client, token, pickup_date=future(6), pickup_time="09:00").status_code == 302
    ids = [r["id"] for r in db_rows(app, "SELECT id FROM bookings ORDER BY id")]
    for i in ids:
        post(admin, f"/admin/bookings/{i}/quote", tok, action="use_estimate")
        post(admin, f"/admin/bookings/{i}/status", tok, status="Confirmed")
    return ids


def test_overlapping_vehicle_assignment_blocked_admin_can_override(app, client, routes):
    routes.km = 50
    admin = app.test_client()
    tok = login(app, admin)
    add_vehicle(admin, tok, "FJ 002")
    v = db_rows(app, "SELECT id FROM vehicles")[0]["id"]
    one, two = two_bookings(app, client, routes, admin, tok)
    post(admin, f"/admin/bookings/{one}/assign", tok, vehicle_id=v)
    post(admin, f"/admin/bookings/{two}/assign", tok, vehicle_id=v)
    assert db_rows(app, "SELECT vehicle_id FROM bookings WHERE id=?", two)[0]["vehicle_id"] is None
    # override needs the box AND a reason
    post(admin, f"/admin/bookings/{two}/assign", tok, vehicle_id=v, override="on")
    assert db_rows(app, "SELECT vehicle_id FROM bookings WHERE id=?", two)[0]["vehicle_id"] is None
    post(admin, f"/admin/bookings/{two}/assign", tok, vehicle_id=v, override="on", override_reason="Second trip is after the first returns")
    assert db_rows(app, "SELECT vehicle_id FROM bookings WHERE id=?", two)[0]["vehicle_id"] == v
    assert "assignment_override" in [h["action"] for h in db_rows(app, "SELECT action FROM booking_history")]


def test_staff_cannot_override_clash(app, client, routes):
    routes.km = 50
    admin = app.test_client()
    tok = login(app, admin)
    staff = app.test_client()
    stok = login(app, staff, "s@example.com", role="staff")
    add_vehicle(admin, tok, "FJ 003")
    v = db_rows(app, "SELECT id FROM vehicles")[0]["id"]
    one, two = two_bookings(app, client, routes, admin, tok)
    post(staff, f"/admin/bookings/{one}/assign", stok, vehicle_id=v)
    post(staff, f"/admin/bookings/{two}/assign", stok, vehicle_id=v, override="on", override_reason="please")
    assert db_rows(app, "SELECT vehicle_id FROM bookings WHERE id=?", two)[0]["vehicle_id"] is None


def test_capacity_warning_blocks_assignment(app, client, routes):
    routes.km = 50
    admin = app.test_client()
    tok = login(app, admin)
    add_vehicle(admin, tok, "FJ 004", seats="2")
    v = db_rows(app, "SELECT id FROM vehicles")[0]["id"]
    token = api_quote(client).json["token"]
    submit_booking(app, client, token, passengers="6")
    b = bid(app)
    post(admin, f"/admin/bookings/{b}/quote", tok, action="use_estimate")
    post(admin, f"/admin/bookings/{b}/status", tok, status="Confirmed")
    post(admin, f"/admin/bookings/{b}/assign", tok, vehicle_id=v)
    assert db_rows(app, "SELECT vehicle_id FROM bookings")[0]["vehicle_id"] is None


# ------------------------------------------------------------ pricing settings
def test_pricing_change_applies_to_new_quotes_only(app, client, routes, booked):
    admin, tok, b = booked
    base = {"first": "1.2", "second": "1.5", "return_rule": "double", "return_factor": "2", "extras": "",
            "note": "Fuel costs rose"}
    r = post(admin, "/admin/pricing", tok, password="wrong-password-123", **base)
    assert db_rows(app, "SELECT COUNT(*) n FROM pricing_versions")[0]["n"] == 1
    post(admin, "/admin/pricing", tok, password="correct-horse-battery", **base)
    assert db_rows(app, "SELECT COUNT(*) n FROM pricing_versions")[0]["n"] == 2
    routes.km = 100
    q = api_quote(client).json["quote"]
    assert q["total"] == "180.00" and q["formula_version"] == "PV2"
    old = db_rows(app, "SELECT * FROM bookings")[0]
    assert (old["estimated_price"], old["first_multiplier"], old["second_multiplier"], old["formula_version"]) == \
        ("176.00", "1.1", "1.6", "PV1")
    # a token issued under PV1 still prices at PV1 (not silently changed)
    page = admin.get("/admin/pricing").get_data(as_text=True)
    assert "PV2" in page and "Fuel costs rose" in page


def test_pricing_rejects_bad_values(app, booked):
    admin, tok, b = booked
    for first in ("0", "-1", "abc", "50", "1.123456"):
        post(admin, "/admin/pricing", tok, password="correct-horse-battery", first=first, second="1.6",
             return_rule="double", note="x")
    assert db_rows(app, "SELECT COUNT(*) n FROM pricing_versions")[0]["n"] == 1


def test_additional_charge_is_disclosed_in_quote(app, client, routes, booked):
    admin, tok, b = booked
    post(admin, "/admin/pricing", tok, password="correct-horse-battery", first="1.1", second="1.6",
         return_rule="double", return_factor="2", extras="Airport fee | 10.00", note="Airport surcharge")
    routes.km = 100
    q = api_quote(client).json["quote"]
    assert q["total"] == "186.00" and q["extras"][0]["label"] == "Airport fee"
    assert any("Airport fee" in l["label"] for l in q["lines"])


# ------------------------------------------------------------ reports, export, retention
def test_reports_page_and_csv_export(app, client, routes):
    make_booking(app, client, routes, customer_name="=HYPERLINK(\"http://evil\")")
    admin = app.test_client()
    tok = login(app, admin)
    b = bid(app)
    post(admin, f"/admin/bookings/{b}/quote", tok, action="use_estimate")
    page = admin.get("/admin/reports").get_data(as_text=True)
    assert "Total booking requests" in page and "Quotations are not revenue" in page
    r = admin.get("/admin/export.csv")
    assert r.mimetype == "text/csv"
    text = r.get_data(as_text=True)
    assert text.startswith("﻿") and "Estimated price FJD" in text
    assert "'=HYPERLINK" in text and ",=HYPERLINK" not in text  # spreadsheet formula injection neutralised
    x = admin.get("/admin/export.xlsx")
    assert x.status_code == 200 and x.data[:2] == b"PK"


def test_retention_anonymises_old_closed_bookings(app, client, routes):
    make_booking(app, client, routes)
    admin = app.test_client()
    tok = login(app, admin)
    b = bid(app)
    post(admin, f"/admin/bookings/{b}/status", tok, status="Cancelled", reason="test")
    from app.db import get_db
    with app.app_context():
        get_db().execute("UPDATE bookings SET updated_at='2000-01-01T00:00:00+00:00'")
        get_db().commit()
    post(admin, "/admin/retention/purge", tok)
    row = db_rows(app, "SELECT * FROM bookings")[0]
    assert row["customer_name"] == "REDACTED" and row["email"] == "redacted@invalid" and row["anonymised_at"]
    assert row["estimated_price"] == "176.00"  # reporting figures kept


def test_business_settings_drive_public_site(app, client):
    admin = app.test_client()
    tok = login(app, admin)
    r = admin.post("/admin/business", data={"csrf_token": tok, "business_name": "Island Carriers Test", "tagline": "t",
        "phone": "+679 700 0000", "whatsapp": "+679 700 0000", "email": "hello@example.com", "address": "", "operating_hours": "",
        "service_areas": "Viti Levu", "about_text": "We are test.", "terms_text": "Terms body", "privacy_text": "Privacy body",
        "cancellation_text": "Cancel body", "faq_text": "Q one?\nAnswer one", "testimonials_text": "", "reference_prefix": "ic",
        "admin_notify_email": "ops@example.com", "quote_valid_days": "7", "default_job_hours": "4", "retention_days": "365",
        "notify_customer_enabled": "on", "notify_admin_enabled": "on"})
    assert r.status_code == 302
    home = client.get("/").get_data(as_text=True)
    assert "Island Carriers Test" in home and "tel:+6797000000" in home and "wa.me/6797000000" in home
    assert "Answer one" in client.get("/faq").get_data(as_text=True)
    assert "Terms body" in client.get("/terms").get_data(as_text=True)
