import time
from datetime import timedelta

import pytest

from app import create_app, maps
from app.maps import Route
from app.util import now_fiji

SUVA = {"address": "Suva, Fiji", "lat": -18.1416, "lng": 178.4415, "place_id": "p1"}
NADI = {"address": "Nadi, Fiji", "lat": -17.8, "lng": 177.4167, "place_id": "p2"}
LAUTOKA = {"address": "Lautoka, Fiji", "lat": -17.6167, "lng": 177.45, "place_id": "p3"}
SYDNEY = {"address": "Sydney, Australia", "lat": -33.87, "lng": 151.21, "place_id": "p4"}


class FakeRoutes:
    """Stands in for Google's Routes API so tests never spend money or need a key."""
    def __init__(self):
        self.km = 100.0
        self.seq = []
        self.mode = "ok"
        self.calls = []

    def __call__(self, origin, dest, api_key, timeout=10):
        self.calls.append((origin, dest))
        if self.mode == "none":
            raise maps.RouteUnavailable("no route")
        if self.mode == "error":
            raise maps.RouteError("boom")
        km = self.seq.pop(0) if self.seq else self.km
        return Route(distance_m=int(round(km * 1000)), duration_s=5400, polyline="_p~iF~ps|U_ulLnnqC_mqNvxq`@")


@pytest.fixture()
def app(tmp_path, monkeypatch):
    monkeypatch.delenv("SMTP_HOST", raising=False)
    return create_app({
        "TESTING": True, "SECRET_KEY": "k" * 48, "DATABASE_PATH": str(tmp_path / "t.db"),
        "UPLOAD_DIR": str(tmp_path / "up"), "GOOGLE_MAPS_SERVER_KEY": "test-key",
        "SMTP_HOST": "", "SITE_URL": "https://carrier.example.test",
    })


@pytest.fixture()
def routes(monkeypatch):
    fake = FakeRoutes()
    monkeypatch.setattr(maps, "compute_route", fake)
    return fake


@pytest.fixture()
def client(app):
    return app.test_client()


def csrf(client):
    client.get("/quote")
    with client.session_transaction() as s:
        return s["csrf"]


def api_quote(client, **over):
    body = {"journey_type": "one_way", "origin": SUVA, "destination": NADI}
    body.update(over)
    return client.post("/api/quote", json=body, headers={"X-CSRF-Token": csrf(client)})


def future(days):
    return (now_fiji() + timedelta(days=days)).date().isoformat()


def submit_booking(app, client, token, booking_type="passenger", **over):
    """Walk the real flow: /book/start -> GET /book -> POST /book. Returns the POST response."""
    t = csrf(client)
    r = client.post("/book/start", json={"mode": "auto", "token": token, "booking_type": booking_type},
                    headers={"X-CSRF-Token": t})
    assert r.status_code == 200 and r.json["ok"], r.data
    assert client.get("/book").status_code == 200
    from app.public import ser
    with app.test_request_context():
        ts = ser("form").dumps(time.time() - 30)
    form = {"csrf_token": t, "booking_type": booking_type, "customer_name": "Test Customer",
            "mobile": "+679 7000000", "email": "cust@example.com", "contact_method": "phone",
            "pickup_date": future(5), "pickup_time": "09:00", "consent_terms": "on",
            "consent_estimate": "on", "consent_comms": "on", "form_ts": ts, "website": ""}
    if booking_type == "passenger":
        form.update(passengers="3", luggage="2 bags")
    else:
        form.update(goods_description="Two fridges", goods_quantity="2 units", assistance="yes")
    form.update(over)
    return client.post("/book", data={k: v for k, v in form.items() if v is not None})


def make_booking(app, client, routes, km=100, **kw):
    routes.km = km
    token = api_quote(client).json["token"]
    r = submit_booking(app, client, token, **kw)
    assert r.status_code == 302, r.data[:2000]
    return r


def login(app, client, email="boss@example.com", pw="correct-horse-battery", role="admin"):
    from app.admin import create_user
    with app.app_context():
        create_user(email, "Boss" if role == "admin" else "Staffer", role, pw)
    r = client.post("/admin/login", data={"email": email, "password": pw, "csrf_token": csrf(client)})
    assert r.status_code == 302, r.data
    return csrf(client)


def db_rows(app, sql, *a):
    from app.db import get_db
    with app.app_context():
        return [dict(r) for r in get_db().execute(sql, a).fetchall()]
