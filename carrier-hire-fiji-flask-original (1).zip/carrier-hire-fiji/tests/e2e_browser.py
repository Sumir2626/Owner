"""Real-browser smoke test (not collected by pytest). Runs the site with a FAKE Google Maps script and a
FAKE Routes API, so no key or billing is needed. Usage: python3 tests/e2e_browser.py <screenshot_dir>"""
import sys, tempfile, threading, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright

from app import create_app, maps
from app.maps import Route
from conftest import future

SHOTS = Path(sys.argv[1] if len(sys.argv) > 1 else "shots"); SHOTS.mkdir(parents=True, exist_ok=True)
tmp = tempfile.mkdtemp()
app = create_app({"TESTING": False, "SECRET_KEY": "k" * 48, "DATABASE_PATH": f"{tmp}/e2e.db", "UPLOAD_DIR": f"{tmp}/up",
                  "GOOGLE_MAPS_BROWSER_KEY": "fake-browser-key", "GOOGLE_MAPS_SERVER_KEY": "fake-server-key",
                  "SITE_URL": "http://127.0.0.1:5055"})
KM = {"v": 100.0}
maps.compute_route = lambda o, d, k, timeout=10: Route(int(KM["v"] * 1000), 5400, "_p~iF~ps|U_ulLnnqC_mqNvxq`@")
with app.app_context():
    from app.admin import create_user
    from app.db import get_db
    create_user("admin@example.com", "Test Admin", "admin", "correct-horse-battery")
    get_db().execute("INSERT INTO vehicles(reg_no,vehicle_type,name,passenger_capacity,cargo_capacity,status,availability_checked_at,show_public,description,created_at) "
                     "VALUES('TEST 1','Minibus','Sample minibus',14,'', 'available','2026-10-28T00:00:00+00:00',1,'Placeholder vehicle for layout testing','2026-10-28T00:00:00+00:00')")
    get_db().commit()
srv = make_server("127.0.0.1", 5055, app, threaded=True)
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = "http://127.0.0.1:5055"

FAKE_GOOGLE = r"""
(function(){
  function Evt(){}
  function LatLngBounds(){ this.pts=[]; } LatLngBounds.prototype.extend=function(p){this.pts.push(p)};
  function Polyline(o){ this.o=o; window.__lines=(window.__lines||0)+1; } Polyline.prototype.setMap=function(){};
  function MapC(el,o){ this.el=el; el.style.background='#cfe3ee'; el.textContent='[fake Google map]'; this.l={}; window.__map=this; }
  MapC.prototype={addListener:function(n,f){this.l[n]=f},setCenter(){},setZoom(){},fitBounds(){}};
  function AC(o){ var d=document.createElement('div'); d.className='fake-ac'; d.textContent='[Places autocomplete]'; (window.__acs=window.__acs||[]).push(d); return d; }
  function Marker(o){ this.map=o.map; window.__markers=(window.__markers||0)+1; }
  function Pin(){ this.element=document.createElement('div'); }
  function Geocoder(){} Geocoder.prototype.geocode=function(){return Promise.resolve({results:[{formatted_address:'Clicked spot, Fiji',place_id:'pc'}]})};
  window.google={maps:{LatLngBounds:LatLngBounds,Polyline:Polyline,geometry:{encoding:{decodePath:function(s){return [{lat:-18,lng:178},{lat:-17.8,lng:177.4}]}}},
    importLibrary:function(n){ return Promise.resolve({maps:{Map:MapC},places:{PlaceAutocompleteElement:AC},marker:{AdvancedMarkerElement:Marker,PinElement:Pin},geocoding:{Geocoder:Geocoder},geometry:{}}[n]) }}};
  if(window.__gmReady) window.__gmReady();
})();
"""
results = []
def check(name, cond, extra=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra and not cond else ""))

def pick(page, idx, name, addr, lat, lng, pid):
    page.evaluate("""([i,n,a,la,ln,p]) => { const ac = window.__acs[i]; const ev = new Event('gmp-select');
      ev.placePrediction = { toPlace: () => ({ fetchFields: async () => {}, location: { lat: () => la, lng: () => ln }, displayName: n, formattedAddress: a, id: p }) };
      ac.dispatchEvent(ev); }""", [idx, name, addr, lat, lng, pid])

with sync_playwright() as pw:
    browser = pw.chromium.launch()
    for label, vp in (("desktop", {"width": 1280, "height": 900}), ("mobile", {"width": 390, "height": 844})):
        ctx = browser.new_context(viewport=vp, device_scale_factor=1)
        page = ctx.new_page()
        csp = []
        page.on("console", lambda m: csp.append(m.text) if "Content Security Policy" in m.text or "Refused" in m.text else None)
        page.route("https://maps.googleapis.com/maps/api/js*", lambda r: r.fulfill(status=200, content_type="text/javascript", body=FAKE_GOOGLE))
        page.route("https://fonts.googleapis.com/**", lambda r: r.abort())
        page.goto(BASE + "/"); page.screenshot(path=str(SHOTS / f"{label}-home.png"), full_page=True)
        for path in ("/about", "/services", "/vehicles", "/faq", "/contact", "/terms", "/privacy", "/booking-status"):
            resp = page.goto(BASE + path); check(f"{label} {path} loads", resp.status == 200)
            hs = page.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1")
            check(f"{label} {path} no horizontal scroll", hs)
        page.goto(BASE + "/vehicles"); page.screenshot(path=str(SHOTS / f"{label}-vehicles.png"), full_page=True)

        # ---- quote flow
        KM["v"] = 100
        page.goto(BASE + "/quote")
        page.wait_for_function("window.__acs && window.__acs.length >= 4")
        page.check("input[name=booking_type][value=passenger]", force=True)
        pick(page, 0, "Suva", "Suva, Fiji", -18.1416, 178.4415, "p1")
        pick(page, 1, "Nadi", "Nadi, Fiji", -17.8, 177.4167, "p2")
        page.wait_for_selector("#quote-panel .total .amt")
        panel = page.inner_text("#quote-panel")
        check(f"{label} 100 km quote shows FJ$176.00", "FJ$176.00" in panel)
        check(f"{label} step 1 shown", "100 km × 1.1 = 110" in panel)
        check(f"{label} step 2 shown", "110 × 1.6 = FJ$176.00" in panel)
        check(f"{label} disclaimer shown", "It is not a confirmed booking or final price" in panel)
        check(f"{label} route polyline drawn + markers", page.evaluate("window.__lines >= 1 && window.__markers >= 2"))
        page.screenshot(path=str(SHOTS / f"{label}-quote-100km.png"), full_page=True)
        # change destination -> recalculates
        KM["v"] = 25
        pick(page, 1, "Lautoka", "Lautoka, Fiji", -17.6167, 177.45, "p3")
        page.wait_for_function("document.querySelector('#quote-panel .amt') && document.querySelector('#quote-panel .amt').textContent.includes('44.00')")
        check(f"{label} changing destination recalculates (25 km = FJ$44.00)", True)
        # return trip
        KM["v"] = 100
        page.check("input[name=journey_type][value=return]", force=True)
        page.wait_for_function("document.querySelector('#quote-panel .amt') && document.querySelector('#quote-panel .amt').textContent.includes('352.00')")
        check(f"{label} switching to return recalculates", True)
        # no route -> manual
        maps.compute_route = lambda o, d, k, timeout=10: (_ for _ in ()).throw(maps.RouteUnavailable("x"))
        pick(page, 1, "Taveuni", "Taveuni, Fiji", -16.85, -179.97, "p9")
        page.wait_for_selector("#quote-panel .notice.bad")
        check(f"{label} no route shows message + manual button, no price", "Request a Manual Quote" in page.inner_text("#quote-panel") and "FJ$" not in page.inner_text("#quote-panel"))
        page.screenshot(path=str(SHOTS / f"{label}-quote-noroute.png"), full_page=True)
        maps.compute_route = lambda o, d, k, timeout=10: Route(int(KM["v"] * 1000), 5400, "_p~iF~ps|U_ulLnnqC_mqNvxq`@")
        pick(page, 1, "Nadi", "Nadi, Fiji", -17.8, 177.4167, "p2")
        page.wait_for_selector("#btn-proceed")
        page.click("#btn-proceed")
        page.wait_for_url("**/book")
        check(f"{label} proceed goes to booking form with quote retained", "FJ$352.00" in page.inner_text("body") and "Suva" in page.inner_text("body"))
        page.fill("#f-customer_name", "Browser Tester"); page.fill("#f-mobile", "7001234"); page.fill("#f-email", "browser@example.com")
        page.fill("#f-pickup_date", future(4)); page.fill("#f-pickup_time", "08:30")
        page.fill("#f-return_date", future(6)); page.fill("#f-return_time", "16:00")
        page.fill("#f-passengers", "4")
        for n in ("consent_terms", "consent_estimate", "consent_comms"):
            page.check(f"input[name={n}]", force=True)
        page.screenshot(path=str(SHOTS / f"{label}-book-form.png"), full_page=True)
        time.sleep(3.2)  # anti-bot minimum fill time
        page.click("#booking-form button[type=submit]")
        page.wait_for_url("**/booking/submitted")
        ref = page.inner_text(".ref-box").strip()
        check(f"{label} booking submitted with reference", ref.startswith("CH-"), ref)
        page.screenshot(path=str(SHOTS / f"{label}-submitted.png"), full_page=True)
        check(f"{label} no CSP violations on public pages", not csp, "; ".join(csp)[:300])

        # ---- admin
        page.goto(BASE + "/admin/login")
        page.fill("input[name=email]", "admin@example.com"); page.fill("input[name=password]", "correct-horse-battery")
        page.click("button[type=submit]"); page.wait_for_url("**/admin/")
        page.screenshot(path=str(SHOTS / f"{label}-admin-dashboard.png"), full_page=True)
        page.goto(BASE + "/admin/bookings"); page.screenshot(path=str(SHOTS / f"{label}-admin-bookings.png"), full_page=True)
        page.click("table a >> nth=0")
        check(f"{label} admin sees booking + estimate", "FJ$352.00" in page.inner_text("body"))
        page.screenshot(path=str(SHOTS / f"{label}-admin-booking.png"), full_page=True)
        for path in ("/admin/pricing", "/admin/business", "/admin/vehicles", "/admin/vehicles/new", "/admin/drivers", "/admin/reports", "/admin/outbox", "/admin/users", "/admin/enquiries"):
            r = page.goto(BASE + path); check(f"{label} admin {path}", r.status == 200)
            check(f"{label} admin {path} no horizontal scroll", page.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"))
        page.goto(BASE + "/admin/pricing"); page.screenshot(path=str(SHOTS / f"{label}-admin-pricing.png"), full_page=True)
        ctx.close()
    browser.close()
srv.shutdown()
bad = [n for n, ok in results if not ok]
print(f"\n{len(results) - len(bad)}/{len(results)} browser checks passed")
sys.exit(1 if bad else 0)
