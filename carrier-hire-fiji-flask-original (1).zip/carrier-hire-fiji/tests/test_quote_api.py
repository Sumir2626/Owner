from conftest import LAUTOKA, NADI, SUVA, SYDNEY, api_quote, csrf


def test_two_fiji_locations_give_distance_and_price(client, routes):
    routes.km = 100
    r = api_quote(client)
    j = r.json
    assert j["ok"] and j["quote"]["total"] == "176.00" and j["quote"]["total_distance_km"] == "100"
    assert j["quote"]["legs"][0]["first_result"] == "110"
    assert j["routes"][0]["polyline"] and "google.com/maps/dir" in j["maps_links"][0]
    assert "token" in j and "176" not in j["token"]  # signed blob, not a plain price field


def test_changing_a_location_recalculates(client, routes):
    routes.km = 100
    first = api_quote(client).json["quote"]["total"]
    routes.km = 25
    second = api_quote(client, destination=LAUTOKA).json["quote"]["total"]
    assert (first, second) == ("176.00", "44.00")
    assert routes.calls[-1][1]["lat"] == LAUTOKA["lat"]


def test_return_trip_is_double(client, routes):
    routes.km = 100
    q = api_quote(client, journey_type="return").json["quote"]
    assert q["one_way_price"] == "176.00" and q["total"] == "352.00"
    assert len(routes.calls) == 1  # same route assumed: one Routes call


def test_return_with_different_route_uses_two_legs(client, routes):
    routes.seq = [100, 60]
    j = api_quote(client, journey_type="return", return_different=True,
                  return_origin=NADI, return_destination=LAUTOKA).json
    assert j["quote"]["total"] == "281.60" and len(j["routes"]) == 2 and len(routes.calls) == 2


def test_no_road_route_offers_manual_quote_and_no_price(client, routes):
    routes.mode = "none"
    j = api_quote(client).json
    assert j["ok"] is False and j["code"] == "no_route" and j["manual_allowed"] is True
    assert "quote" not in j and "total" not in str(j)


def test_google_error_never_creates_a_price(client, routes):
    routes.mode = "error"
    j = api_quote(client).json
    assert j["ok"] is False and j["code"] == "api_error" and "quote" not in j and j["manual_allowed"]


def test_missing_server_key_falls_back_to_manual(client, app, routes):
    app.config["GOOGLE_MAPS_SERVER_KEY"] = ""
    j = api_quote(client).json
    assert j["code"] == "not_configured" and j["manual_allowed"] and not routes.calls


def test_outside_fiji_rejected_before_calling_google(client, routes):
    r = api_quote(client, destination=SYDNEY)
    assert r.status_code == 422 and r.json["code"] == "outside_fiji" and not routes.calls


def test_same_place_rejected(client, routes):
    r = api_quote(client, destination=SUVA)
    assert r.status_code == 422 and r.json["code"] == "same_place"


def test_bad_input_rejected(client, routes):
    assert api_quote(client, journey_type="sideways").status_code == 400
    assert api_quote(client, origin={"lat": "x", "lng": 1}).status_code == 400
    assert api_quote(client, destination=None).status_code == 400


def test_client_cannot_inject_distance_or_price(client, routes):
    routes.km = 100
    j = api_quote(client, distance_km=1, total="1.00", price=1, distance_m=1000).json
    assert j["quote"]["total"] == "176.00"


def test_csrf_required_on_api(client, routes):
    r = client.post("/api/quote", json={"journey_type": "one_way", "origin": SUVA, "destination": NADI})
    assert r.status_code == 400


def test_quote_rate_limit(client, routes):
    codes = [api_quote(client).status_code for _ in range(45)]
    assert 429 in codes
