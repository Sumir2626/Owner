import json

from conftest import (LAUTOKA, NADI, SUVA, api_quote, csrf, db_rows, future, login, make_booking,
                      submit_booking)


def test_booking_submission_stores_everything_and_notifies(app, client, routes):
    make_booking(app, client, routes, km=100)
    (b,) = db_rows(app, "SELECT * FROM bookings")
    assert b["reference"].startswith("CH-") and b["status"] == "Pending Review"
    assert (b["distance_km"], b["first_multiplier"], b["second_multiplier"], b["first_result"]) == ("100", "1.1", "1.6", "110")
    assert b["estimated_price"] == "176.00" and b["final_quote"] is None and b["currency"] == "FJD"
    assert b["formula_version"] == "PV1" and b["quote_mode"] == "auto"
    assert b["pickup_lat"] == SUVA["lat"] and b["dest_address"] == "Nadi, Fiji"
    assert json.loads(b["details"])["passengers"] == 3
    mails = db_rows(app, "SELECT kind, to_addr, body_text FROM email_outbox ORDER BY id")
    assert [m["kind"] for m in mails] == ["customer_received", "admin_new_booking"]
    assert "NOT YET A CONFIRMED BOOKING" in mails[0]["body_text"]
    assert "ESTIMATED QUOTATION" in mails[0]["body_text"] and "FINAL APPROVED" not in mails[0]["body_text"]
    # confirmation page shows the reference
    page = client.get("/booking/submitted").get_data(as_text=True)
    assert b["reference"] in page


def test_return_booking_stores_double_and_return_times(app, client, routes):
    routes.km = 100
    token = api_quote(client, journey_type="return").json["token"]
    r = submit_booking(app, client, token, return_date=future(7), return_time="17:00")
    assert r.status_code == 302
    (b,) = db_rows(app, "SELECT * FROM bookings")
    assert b["journey_type"] == "return" and b["estimated_price"] == "352.00" and b["return_dt"].endswith("17:00")


def test_goods_booking_with_photo(app, client, routes, tmp_path):
    import io
    routes.km = 50
    token = api_quote(client).json["token"]
    png = b"\x89PNG\r\n\x1a\n" + b"0" * 100
    r = submit_booking(app, client, token, booking_type="goods", photos=(io.BytesIO(png), "fridge.png"))
    assert r.status_code == 302
    (b,) = db_rows(app, "SELECT * FROM bookings")
    assert b["booking_type"] == "goods" and b["estimated_price"] == "88.00"
    photos = json.loads(b["photos"])
    assert len(photos) == 1 and photos[0].endswith(".png")


def test_fake_image_is_rejected(app, client, routes):
    import io
    routes.km = 50
    token = api_quote(client).json["token"]
    r = submit_booking(app, client, token, booking_type="goods", photos=(io.BytesIO(b"<?php evil ?>"), "x.png"))
    assert r.status_code == 422 and not db_rows(app, "SELECT 1 FROM bookings")


def test_validation_messages(app, client, routes):
    routes.km = 100
    token = api_quote(client).json["token"]
    r = submit_booking(app, client, token, customer_name="", email="nope", mobile="abc", consent_terms=None,
                       pickup_date="2001-01-01", passengers="0")
    page = r.get_data(as_text=True)
    assert r.status_code == 422
    for msg in ("Please enter your full name", "valid email", "valid mobile", "agree to the Terms",
                "must be in the future", "number of passengers"):
        assert msg in page
    assert not db_rows(app, "SELECT 1 FROM bookings")


def test_return_date_must_follow_pickup(app, client, routes):
    routes.km = 100
    token = api_quote(client, journey_type="return").json["token"]
    r = submit_booking(app, client, token, return_date=future(2), return_time="10:00")
    assert r.status_code == 422 and "after the pickup" in r.get_data(as_text=True)


def test_tampered_or_expired_token_rejected(app, client, routes):
    routes.km = 100
    token = api_quote(client).json["token"]
    bad = token[:-3] + ("AAA" if not token.endswith("AAA") else "BBB")
    r = client.post("/book/start", json={"mode": "auto", "token": bad, "booking_type": "passenger"},
                    headers={"X-CSRF-Token": csrf(client)})
    assert r.status_code == 400


def test_customer_cannot_override_price_or_distance(app, client, routes):
    routes.km = 100
    token = api_quote(client).json["token"]
    submit_booking(app, client, token, estimated_price="1.00", distance_km="1", final_quote="1", status="Confirmed",
                   first_multiplier="0.1")
    (b,) = db_rows(app, "SELECT * FROM bookings")
    assert (b["estimated_price"], b["distance_km"], b["status"], b["final_quote"]) == ("176.00", "100", "Pending Review", None)


def test_honeypot_and_speed_trap(app, client, routes):
    routes.km = 100
    token = api_quote(client).json["token"]
    r = submit_booking(app, client, token, website="http://spam.example")
    assert r.status_code == 302 and not db_rows(app, "SELECT 1 FROM bookings")
    # too fast: fresh form timestamp
    import time
    from app.public import ser
    with app.test_request_context():
        fresh = ser("form").dumps(time.time())
    r = submit_booking(app, client, token, form_ts=fresh)
    assert r.status_code == 422 and not db_rows(app, "SELECT 1 FROM bookings")


def test_booking_rate_limit(app, client, routes):
    routes.km = 10
    token = api_quote(client).json["token"]
    codes = [submit_booking(app, client, token).status_code for _ in range(10)]
    assert codes.count(302) == 8 and 422 in codes


def test_manual_quote_request_without_route(app, client, routes):
    routes.mode = "none"
    t = csrf(client)
    r = client.post("/book/start", json={"mode": "manual", "booking_type": "goods", "journey_type": "one_way",
                    "origin": {"address": "Rotuma village", "lat": -12.5, "lng": 177.07},
                    "destination": {"address": "Suva wharf"}, "reason": "no_route"}, headers={"X-CSRF-Token": t})
    assert r.json["ok"]
    from app.public import ser
    import time
    with app.test_request_context():
        ts = ser("form").dumps(time.time() - 30)
    r = client.post("/book", data={"csrf_token": t, "booking_type": "goods", "customer_name": "Sera", "mobile": "7000000",
                    "email": "sera@example.com", "contact_method": "email", "pickup_date": future(3), "pickup_time": "08:00",
                    "pickup_address": "Rotuma village", "dest_address": "Suva wharf", "journey_type": "one_way",
                    "goods_description": "Kava", "assistance": "no", "consent_terms": "on", "consent_estimate": "on",
                    "consent_comms": "on", "form_ts": ts})
    assert r.status_code == 302
    (b,) = db_rows(app, "SELECT * FROM bookings")
    assert b["quote_mode"] == "manual" and b["estimated_price"] is None and b["status"] == "Pending Review"
    kinds = [m["kind"] for m in db_rows(app, "SELECT kind FROM email_outbox")]
    assert "admin_new_manual_quote" in kinds


def test_book_page_without_quote_redirects(client):
    r = client.get("/book")
    assert r.status_code == 302 and "/quote" in r.headers["Location"]


def test_customer_status_page_and_actions(app, client, routes):
    make_booking(app, client, routes)
    (b,) = db_rows(app, "SELECT * FROM bookings")
    ref = b["reference"]
    c2 = app.test_client()
    # not visible without reference + email, and no data in URLs
    assert c2.get(f"/booking-status/{ref}").status_code == 302
    bad = c2.post("/booking-status", data={"reference": ref, "email": "other@example.com", "csrf_token": csrf(c2)})
    assert "could not find" in bad.get_data(as_text=True)
    ok = c2.post("/booking-status", data={"reference": ref, "email": "CUST@example.com", "csrf_token": csrf(c2)})
    assert ok.status_code == 302
    page = c2.get(f"/booking-status/{ref}").get_data(as_text=True)
    assert "Pending Review" in page and "FJ$176.00" in page
    r = c2.post(f"/booking-status/{ref}/request-cancel", data={"message": "Plans changed", "csrf_token": csrf(c2)})
    assert r.status_code == 302
    kinds = [m["kind"] for m in db_rows(app, "SELECT kind FROM email_outbox")]
    assert "admin_cancel_request" in kinds
    assert db_rows(app, "SELECT status FROM bookings")[0]["status"] == "Pending Review"  # unchanged until admin acts
    # cannot accept a quotation that has not been sent
    c2.post(f"/booking-status/{ref}/accept-quote", data={"csrf_token": csrf(c2)})
    assert db_rows(app, "SELECT quote_status FROM bookings")[0]["quote_status"] == "none"
